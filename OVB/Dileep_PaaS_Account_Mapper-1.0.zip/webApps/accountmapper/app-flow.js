define([], function () {
  'use strict';

  var AppModule = function AppModule() { };
  
   AppModule.prototype.assignGRMRoles = function (data, email) {
    var userRole;
    var userrole1 = "MCD_EXTN_PAAS_MAPPER_READWRITE", userrole2 = "MCD_EXTN_PAAS_MAPPER_READONLY";
   if(data === undefined){
    userRole = undefined;
   }
   else if (data.length !== 0){
    for (var j = 0; j < data.length; j++) {
      if (data[j].attributes.ExternalAppRole != undefined && data[j].attributes.ExternalAppRole != null && data[j].attributes.ExternalAppRole != ""){


         if(data[j].attributes.ExternalAppRole == userrole1 || data[j].attributes.ExternalAppRole == userrole2){
             userRole = data[j].attributes.ExternalAppRole;
          
        }
       
      }

    }
   }
   return userRole;
  };

    AppModule.prototype.removeDuplicatesledgerADP = function (data) {
    
    return [...new Map(data.map(item => [item["set_of_boks_name"], item])).values()];

  };

  return AppModule;
});