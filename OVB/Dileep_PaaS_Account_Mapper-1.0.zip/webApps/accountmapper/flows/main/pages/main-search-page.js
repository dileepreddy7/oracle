define([], function () {
  'use strict';

  var PageModule = function PageModule() { };

  /*setting up query parameter for search criteria */
  PageModule.prototype.setParamVariable = function (mapperName, description, company, accountNo, lineOfBusiness, location, hrDeptCostCentre, ledger) {
    var searchParam = "";

    if (ledger != undefined && ledger != null && ledger != "") {
      if (mapperName != undefined && mapperName != null) {

        /*account search results */
        if (mapperName == "ACCOUNT") {

          if ((accountNo != undefined && accountNo != null && accountNo != "") && (lineOfBusiness != undefined && lineOfBusiness != null && lineOfBusiness != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment5\"" + ":" + "\"" + accountNo + "\"" + "," + "\"orcl_segment2\"" + ":" + "\"" + lineOfBusiness + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((accountNo != undefined && accountNo != null && accountNo != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment5\"" + ":" + "\"" + accountNo + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((lineOfBusiness != undefined && lineOfBusiness != null && lineOfBusiness != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment2\"" + ":" + "\"" + lineOfBusiness + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((accountNo != undefined && accountNo != null && accountNo != "") && (lineOfBusiness != undefined && lineOfBusiness != null && lineOfBusiness != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment5\"" + ":" + "\"" + accountNo + "\"" + "," + "\"orcl_segment2\"" + ":" + "\"" + lineOfBusiness + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (accountNo != undefined && accountNo != null && accountNo != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment5\"" + ":" + "\"" + accountNo + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (lineOfBusiness != undefined && lineOfBusiness != null && lineOfBusiness != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment2\"" + ":" + "\"" + lineOfBusiness + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (description != undefined && description != null && description != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
        }

        /*company search results */
        else if (mapperName == "COMPANY") {

          if ((company != undefined && company != null && company != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if (company != undefined && company != null && company != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (description != undefined && description != null && description != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
        }

        /*department search results */
        else if (mapperName == "DEPARTMENT") {

          if ((company != undefined && company != null && company != "") && (location != undefined && location != null && location != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((company != undefined && company != null && company != "") && (location != undefined && location != null && location != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((company != undefined && company != null && company != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((location != undefined && location != null && location != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((company != undefined && company != null && company != "") && (location != undefined && location != null && location != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if ((company != undefined && company != null && company != "") && (location != undefined && location != null && location != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if ((company != undefined && company != null && company != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if ((location != undefined && location != null && location != "") && (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if ((company != undefined && company != null && company != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((location != undefined && location != null && location != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if ((hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "") && (description != undefined && description != null && description != "")) {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else if (company != undefined && company != null && company != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment1\"" + ":" + "\"" + company + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (location != undefined && location != null && location != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment3\"" + ":" + "\"" + location + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (hrDeptCostCentre != undefined && hrDeptCostCentre != null && hrDeptCostCentre != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"orcl_segment4\"" + ":" + "\"" + hrDeptCostCentre + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
          else if (description != undefined && description != null && description != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
        }

        /*MSIS search results */
        if (mapperName == "MSIS ACCOUNT NUMBER") {
          if (description != undefined && description != null && description != "") {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"" + "," + "\"description\"" + ":" + "\{" + "\"$instr\"" + ":" + "\"" + description + "\"}}";
          }
          else {
            searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"attribute1\"" + ":" + "\"" + ledger + "\"}";
          }
        }
      }
    }
    console.log("Printing value" + searchParam);
    return searchParam;
  };


  PageModule.prototype.setParamVariableforDuplicate = function (ledger, mapperName) {
    var searchParam = "";
    if (ledger != undefined && ledger != null && ledger != "") {
      if (mapperName != undefined && mapperName != null) {
        searchParam = "{" + "\"lookup_type\"" + ":" + "\"" + mapperName + "\"" + "," + "\"set_of_books_name\"" + ":" + "\"" + ledger + "\"}";
      }
    }
    console.log("Printing value" + searchParam);
    return searchParam;
  };


  PageModule.prototype.fieldvalidations = function (ledger, mapper) {
    var errorMsg;

    if ((ledger == undefined || ledger == null || ledger == "") && (mapper == undefined || mapper == null || mapper == "")) {
      errorMsg = "The Ledger and Mapper must be populated in order to proceed";
    }
    else if (mapper == undefined || mapper == null || mapper == "") {
      errorMsg = "Mapper is required and must be populated";
    }
    else if (ledger == undefined || ledger == null || ledger == "") {
      errorMsg = "Ledger is required and must be populated";
    }

    console.log(errorMsg);
    return errorMsg;
  };

  //generating unique id for new row in editable table
  PageModule.prototype.getNextId = function (searchResultTableVariables, mapper_id) {
    var nextIdValue;
    var newId = 0;
    if (nextIdValue === undefined) {
      for (var i = 0; i < searchResultTableVariables.length; i++) {
        newId = i;
      }
      nextIdValue = newId;
      searchResultTableVariables.forEach(s => {
        if (s.mapper_id > nextIdValue) nextIdValue = s.mapper_id;
      });
    }
    ++nextIdValue;
    return nextIdValue;
  };


  PageModule.prototype.duplicateRecordsCheck = function (recArr, searchArr) {

    for (var j = 0; j < recArr.length; j++) {

      var lookupType = recArr[j].lookup_type;
      var start_date = "", end_date = "", company = "", lgcyCompany = "", interfaceType = "", lineOfBusiness = "", accountNo = "", msisAccountNo = "", location = "", hrDeptCostCentre = "", main = "", sub = "", lookup ="", descrptn ="" ;

      if (recArr[j].action == "I" || recArr[j].action == "F") {

        if (recArr[j].start_date_active != undefined && recArr[j].start_date_active != null && recArr[j].start_date_active != "") {
          start_date = recArr[j].start_date_active.substring(0, 10); //2022-05-26T05:00:00Z
        }

        if (recArr[j].end_date_active != undefined && recArr[j].end_date_active != null && recArr[j].end_date_active != "") {
          end_date = recArr[j].end_date_active.substring(0, 10);
        }

        company = recArr[j].orcl_segment1;
        lgcyCompany = recArr[j].lgcy_segment1;
        interfaceType = recArr[j].interface_type;
        lineOfBusiness = recArr[j].orcl_segment2;
        accountNo = recArr[j].orcl_segment5;
        msisAccountNo = recArr[j].lgcy_segment1;
        location = recArr[j].orcl_segment3;
        hrDeptCostCentre = recArr[j].orcl_segment4;
        main = recArr[j].lgcy_segment1;
        sub = recArr[j].lgcy_segment2;
        lookup = recArr[j].lookup_code;
        descrptn = recArr[j].description;

        for (var i = 0; i < searchArr.length; i++) {

          var start_date1 = "", end_date1 = "", company1 = "", lgcyCompany1 = "", interfaceType1 = "", lineOfBusiness1 = "", accountNo1 = "", msisAccountNo1 = "", location1 = "", hrDeptCostCentre1 = "", main1 = "", sub1 = "", lookup1 ="", descrptn1 ="";

          if (searchArr[i].start_date_active != undefined && searchArr[i].start_date_active != null && searchArr[i].start_date_active != "") {
            start_date1 = searchArr[i].start_date_active.substring(0, 10);
          }

          if (searchArr[i].end_date_active != undefined && searchArr[i].end_date_active != null && searchArr[i].end_date_active != "") {
            end_date1 = searchArr[i].end_date_active.substring(0, 10);
          }

          company1 = searchArr[i].orcl_segment1;
          lgcyCompany1 = searchArr[i].lgcy_segment1;
          interfaceType1 = searchArr[i].interface_type;
          lineOfBusiness1 = searchArr[i].orcl_segment2;
          accountNo1 = searchArr[i].orcl_segment5;
          msisAccountNo1 = searchArr[i].lgcy_segment1;
          location1 = searchArr[i].orcl_segment3;
          hrDeptCostCentre1 = searchArr[i].orcl_segment4;
          main1 = searchArr[i].lgcy_segment1;
          sub1 = searchArr[i].lgcy_segment2;
          lookup1 = searchArr[i].lookup_code;
          descrptn1 = searchArr[i].description;


          if (lookupType == "COMPANY") {
            if (start_date == start_date1 && end_date == end_date1 && company == company1 && lgcyCompany == lgcyCompany1 && interfaceType == interfaceType1) {
              return false;
            }
          }

          if (lookupType == "ACCOUNT") {
            if (start_date == start_date1 && end_date == end_date1 && lineOfBusiness == lineOfBusiness1 && accountNo == accountNo1 && msisAccountNo == msisAccountNo1 && interfaceType == interfaceType1) {
              return false;
            }
          }

          if (lookupType == "DEPARTMENT") {
            if (start_date == start_date1 && end_date == end_date1 && company == company1 && location == location1 && hrDeptCostCentre == hrDeptCostCentre1 && main == main1 && sub == sub1 && interfaceType == interfaceType1) {
              return false;
            }
          }

          if (lookupType == "MSIS ACCOUNT NUMBER") {
            if (start_date == start_date1 && end_date == end_date1 && msisAccountNo == msisAccountNo1 && interfaceType == interfaceType1) {
              return false;
            }
          }

          if (lookupType == "MCD_TRIRIGA_MAPPER") {
            if (start_date == start_date1 && end_date == end_date1 && lineOfBusiness == lineOfBusiness1 && accountNo == accountNo1 && interfaceType == interfaceType1 && lookup == lookup1 && descrptn ==descrptn1) {
              return false;
            }
          }

        }
      }
    }
    return true;
  };


  PageModule.prototype.duplicateRecordsCheckforNewRecords = function (recArr) {

    for (var j = 0; j < recArr.length; j++) {

      var lookupType = recArr[j].lookup_type;
      var start_date = "", end_date = "", company = "", lgcyCompany = "", interfaceType = "", lineOfBusiness = "", accountNo = "", msisAccountNo = "", location = "", hrDeptCostCentre = "", main = "", sub = "", lookup = "", descrptn ="";

      if (recArr[j].action == 'I' || recArr[j].action == 'F') {

        if (recArr[j].start_date_active != undefined && recArr[j].start_date_active != null && recArr[j].start_date_active != "") {
          start_date = recArr[j].start_date_active.substring(0, 10);
        }

        if (recArr[j].end_date_active != undefined && recArr[j].end_date_active != null && recArr[j].end_date_active != "") {
          end_date = recArr[j].end_date_active.substring(0, 10);
        }

        company = recArr[j].orcl_segment1;
        lgcyCompany = recArr[j].lgcy_segment1;
        interfaceType = recArr[j].interface_type;
        lineOfBusiness = recArr[j].orcl_segment2;
        accountNo = recArr[j].orcl_segment5;
        msisAccountNo = recArr[j].lgcy_segment1;
        location = recArr[j].orcl_segment3;
        hrDeptCostCentre = recArr[j].orcl_segment4;
        main = recArr[j].lgcy_segment1;
        sub = recArr[j].lgcy_segment2;
        lookup = recArr[j].lookup_code;
        descrptn = recArr[j].description;

        for (var i = j + 1; i < recArr.length; i++) {

          var start_date1 = "", end_date1 = "", company1 = "", lgcyCompany1 = "", interfaceType1 = "", lineOfBusiness1 = "", accountNo1 = "", msisAccountNo1 = "", location1 = "", hrDeptCostCentre1 = "", main1 = "", sub1 = "", lookup1 ="", descrptn1 ="";

          if (recArr[i].action == 'I' || recArr[i].action == 'F') {

            if (recArr[i].start_date_active != undefined && recArr[i].start_date_active != null && recArr[i].start_date_active != "") {
              start_date1 = recArr[i].start_date_active.substring(0, 10);
            }

            if (recArr[i].end_date_active != undefined && recArr[i].end_date_active != null && recArr[i].end_date_active != "") {
              end_date1 = recArr[i].end_date_active.substring(0, 10);
            }

            company1 = recArr[i].orcl_segment1;
            lgcyCompany1 = recArr[i].lgcy_segment1;
            interfaceType1 = recArr[i].interface_type;
            lineOfBusiness1 = recArr[i].orcl_segment2;
            accountNo1 = recArr[i].orcl_segment5;
            msisAccountNo1 = recArr[i].lgcy_segment1;
            location1 = recArr[i].orcl_segment3;
            hrDeptCostCentre1 = recArr[i].orcl_segment4;
            main1 = recArr[i].lgcy_segment1;
            sub1 = recArr[i].lgcy_segment2;
            lookup1 = recArr[i].lookup_code;
            descrptn1 = recArr[i].description;


            if (lookupType == "COMPANY") {
              if (start_date == start_date1 && end_date == end_date1 && company == company1 && lgcyCompany == lgcyCompany1 && interfaceType == interfaceType1) {
                return false;
              }
            }

            if (lookupType == "ACCOUNT") {
              if (start_date == start_date1 && end_date == end_date1 && lineOfBusiness == lineOfBusiness1 && accountNo == accountNo1 && msisAccountNo == msisAccountNo1 && interfaceType == interfaceType1) {
                return false;
              }
              else if (start_date == start_date1 && end_date == end_date1 && lineOfBusiness == lineOfBusiness1 && interfaceType == interfaceType1 && accountNo == accountNo1 && msisAccountNo != msisAccountNo1) {
                return false;
              }
            }

            if (lookupType == "DEPARTMENT") {
              if (start_date == start_date1 && end_date == end_date1 && company == company1 && location == location1 && hrDeptCostCentre == hrDeptCostCentre1 && main == main1 && sub == sub1 && interfaceType == interfaceType1) {
                return false;
              }
            }

            if (lookupType == "MSIS ACCOUNT NUMBER") {
              if (start_date == start_date1 && end_date == end_date1 && msisAccountNo == msisAccountNo1 && interfaceType == interfaceType1) {
                return false;
              }
            }

            if (lookupType == "MCD_TRIRIGA_MAPPER") {
              if (start_date == start_date1 && end_date == end_date1 && lineOfBusiness == lineOfBusiness1 && accountNo == accountNo1 && interfaceType == interfaceType1 && lookup == lookup1 && descrptn == descrptn1) {
                return false;
              }
            }

          }
        }
      }
    }
    return true;
  };

  /* mandatory and UI(length and data validation) field validations */
  PageModule.prototype.tableFieldValidations = function (searchVar) {
    var errorMessage;

    for (var j = 0; j < searchVar.length; j++) {

      if (searchVar[j].enable_flag == undefined) {
        if (searchVar[j].action == 'I' || searchVar[j].action == 'F') {

          if (searchVar[j].lookup_type == "COMPANY") {
            if ((searchVar[j].orcl_segment1 == undefined || searchVar[j].orcl_segment1 == null || searchVar[j].orcl_segment1 == "") && (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") && (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") && (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") && (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "")) {
              errorMessage = "Please enter all mandatory values in the new record";
            }
            else if (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") {
              errorMessage = "DESCRIPTION is a required field and must be populated";
            }
            else if (searchVar[j].description.length > 240) {
              errorMessage = "DESCRIPTION can only be 240 positions long";
            }
            else if (searchVar[j].orcl_segment1 == undefined || searchVar[j].orcl_segment1 == null || searchVar[j].orcl_segment1 == "") {
              errorMessage = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
            }
            else if (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") {
              errorMessage = "LGCY_SEGMENT2 (Company) is a required field and must be populated";
            }
            else if ((searchVar[j].lgcy_segment1.toString().length != 3) || (/^\d+$/.test(searchVar[j].lgcy_segment1) == false)) {
              errorMessage = "LGCY_SEGMENT2 (Company) must be 3 positions long and numeric";
            }
            else if (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") {
              errorMessage = "START DATE is a required field and must be populated";
            }
            else if (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "") {
              errorMessage = "INTERFACE_TYPE is a required field and must be populated";
            }
            else if ((searchVar[j].start_date_active != undefined) && (searchVar[j].end_date_active != undefined) && (searchVar[j].end_date_active < searchVar[j].start_date_active)) {
              errorMessage = "END DATE cannot be prior to start date";
            }
          }

          if (searchVar[j].lookup_type == "ACCOUNT") {
			    console.log("tableFieldValidations");
            if ((searchVar[j].orcl_segment2 == undefined || searchVar[j].orcl_segment2 == null || searchVar[j].orcl_segment2 == "") && (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") && (searchVar[j].orcl_segment5 == undefined || searchVar[j].orcl_segment5 == null || searchVar[j].orcl_segment5 == "") && (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") && (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") && (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "")) {
              errorMessage = "Please enter all mandatory values in the new record";
            }
            else if (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") {
              errorMessage = "DESCRIPTION is a required field and must be populated";
            }
            else if (searchVar[j].description.length > 240) {
              errorMessage = "DESCRIPTION can only be 240 positions long";
            }
            else if (searchVar[j].orcl_segment2 == undefined || searchVar[j].orcl_segment2 == null || searchVar[j].orcl_segment2 == "") {
              errorMessage = "ORCL_SEGMENT2 (Line of Business) is a required field and must be populated";
            }
            else if (searchVar[j].orcl_segment5 == undefined || searchVar[j].orcl_segment5 == null || searchVar[j].orcl_segment5 == "") {
              errorMessage = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
            }
            else if ((searchVar[j].orcl_segment5.toString().length != 9) || isNaN(searchVar[j].orcl_segment5)) {
              errorMessage = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
            }
            else if (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") {
              errorMessage = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
            } 
			// commented as part of PRB9023639
	      //  else if (jsonArr[j].lgcy_segment1.toString().length > 9)  {
         //     errorMessage = "LGCY_SEGMENT1 (MSIS Account 1#) must be 9 positions long and numeric";
        //    }
           
            else if (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") {
              errorMessage = "START DATE is a required field and must be populated";
            }
            else if (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "") {
              errorMessage = "INTERFACE_TYPE is a required field and must be populated";
            }
            else if ((searchVar[j].start_date_active != undefined) && (searchVar[j].end_date_active != undefined) && (searchVar[j].end_date_active < searchVar[j].start_date_active)) {
              errorMessage = "END DATE cannot be prior to start date";
            }
          }

          if (searchVar[j].lookup_type == "DEPARTMENT") {
            if ((searchVar[j].orcl_segment1 == undefined || searchVar[j].orcl_segment1 == null || searchVar[j].orcl_segment1 == "") && (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") && (searchVar[j].orcl_segment3 == undefined || searchVar[j].orcl_segment3 == null || searchVar[j].orcl_segment3 == "") && (searchVar[j].orcl_segment4 == undefined || searchVar[j].orcl_segment4 == null || searchVar[j].orcl_segment4 == "") && (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") && (searchVar[j].lgcy_segment2 == undefined || searchVar[j].lgcy_segment2 == null || searchVar[j].lgcy_segment2 == "") && (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") && (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "")) {
              errorMessage = "Please enter all mandatory values in the new record";
            }
            else if (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") {
              errorMessage = "DESCRIPTION is a required field and must be populated";
            }
            else if (searchVar[j].description.length > 240) {
              errorMessage = "DESCRIPTION can only be 240 positions long";
            }
            else if (searchVar[j].orcl_segment1 == undefined || searchVar[j].orcl_segment1 == null || searchVar[j].orcl_segment1 == "") {
              errorMessage = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
            }
            else if (searchVar[j].orcl_segment3 == undefined || searchVar[j].orcl_segment3 == null || searchVar[j].orcl_segment3 == "") {
              errorMessage = "ORCL_SEGMENT3 (Location) is a required field and must be populated";
            }
            else if (searchVar[j].orcl_segment4 == undefined || searchVar[j].orcl_segment4 == null || searchVar[j].orcl_segment4 == "") {
              errorMessage = "ORCL_SEGMENT4 (HR Dept Cost Center) is a required field and must be populated";
            }
            else if (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") {
              errorMessage = "LGCY_SEGMENT3 (Main (Site/Dept)) is a required field and must be populated";
            }
            // changed the condtion from (jsonArr[j].lgcy_segment1.toString().length != 8) to (jsonArr[j].lgcy_segment1.toString().length > 8) 
            else if ((searchVar[j].lgcy_segment1.toString().length > 8) || (/^\d+$/.test(searchVar[j].lgcy_segment1) == false)) {
              errorMessage = "LGCY_SEGMENT3 (Main (Site/Dept)) must be 8 positions long and numeric";
            }
           // else if (searchVar[j].lgcy_segment2 == undefined || searchVar[j].lgcy_segment2 == null || searchVar[j].lgcy_segment2 == "") {
           //   errorMessage = "LGCY_SEGMENT4 (Sub (Site/Dept)) is a required field and must be populated";
            //}
            // changed the condtion from (jsonArr[j].lgcy_segment2.toString().length != 2) to (jsonArr[j].lgcy_segment2.toString().length > 2) 
			// New changes to modify lgcy_segment2 length to 1 PRB9023639
            else if ((searchVar[j].lgcy_segment2.toString().length > 1) || (/^\d+$/.test(searchVar[j].lgcy_segment2) == false)) {
              errorMessage = "LGCY_SEGMENT4 (Sub (Site/Dept)) must be 1 position long and numeric";
            }
            else if (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") {
              errorMessage = "START DATE is a required field and must be populated";
            }
            else if (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "") {
              errorMessage = "INTERFACE_TYPE is a required field and must be populated";
            }
            else if ((searchVar[j].start_date_active != undefined) && (searchVar[j].end_date_active != undefined) && (searchVar[j].end_date_active < searchVar[j].start_date_active)) {
              errorMessage = "END DATE cannot be prior to start date";
            }
          }

          if (searchVar[j].lookup_type == "MSIS ACCOUNT NUMBER") {
            if ((searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") && (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") && (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") && (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "")) {
              errorMessage = "Please enter all mandatory values in the new record";
            }
            else if (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") {
              errorMessage = "DESCRIPTION is a required field and must be populated";
            }
            else if (searchVar[j].description.length > 240) {
              errorMessage = "DESCRIPTION can only be 240 positions long";
            }
            else if (searchVar[j].lgcy_segment1 == undefined || searchVar[j].lgcy_segment1 == null || searchVar[j].lgcy_segment1 == "") {
              errorMessage = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
            }
			// New changes to modify lgcy_segment1 length to 9 PRB9023639
			// else if ((searchVar[j].lgcy_segment1.toString().length != 7) || (/^\d+$/.test(searchVar[j].lgcy_segment1) == false)) {
               else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && (jsonArr[j].lgcy_segment1.toString().length > 9) ) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be 9 positions long";
		  console.log("TESTCASE2");
        //console.log(test);
		//console.log(temp);
		//console.log(data);
        }
		else if ((/^\d+$/.test(jsonArr[j].lgcy_segment1)) == false) {
			jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be Numeric";
		  //console.log("TESTCASE2");
		}  
            else if (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") {
              errorMessage = "START DATE is a required field and must be populated";
            }
            else if (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "") {
              errorMessage = "INTERFACE_TYPE is a required field and must be populated";
            }
            else if ((searchVar[j].start_date_active != undefined) && (searchVar[j].end_date_active != undefined) && (searchVar[j].end_date_active < searchVar[j].start_date_active)) {
              errorMessage = "END DATE cannot be prior to start date";
            }
          }

          if (searchVar[j].lookup_type == "MCD_TRIRIGA_MAPPER") {
            if ((searchVar[j].lookup_code == undefined || searchVar[j].lookup_code == null || searchVar[j].lookup_code == "") && (searchVar[j].orcl_segment2 == undefined || searchVar[j].orcl_segment2 == null || searchVar[j].orcl_segment2 == "") && (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") && (searchVar[j].orcl_segment5 == undefined || searchVar[j].orcl_segment5 == null || searchVar[j].orcl_segment5 == "") && (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") && (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "")) {
              errorMessage = "Please enter all mandatory values in the new record";
            }
            else if (searchVar[j].lookup_code == undefined || searchVar[j].lookup_code == null || searchVar[j].lookup_code == "") {
              errorMessage = "LOOKUP_CODE is a required field and must be populated";
            }
            else if (searchVar[j].description == undefined || searchVar[j].description == null || searchVar[j].description == "") {
              errorMessage = "DESCRIPTION is a required field and must be populated";
            }
            else if (searchVar[j].description.length > 240) {
              errorMessage = "DESCRIPTION can only be 240 positions long";
            }
            else if (searchVar[j].orcl_segment2 == undefined || searchVar[j].orcl_segment2 == null || searchVar[j].orcl_segment2 == "") {
              errorMessage = "ORCL_SEGMENT2 (Line of Business) is a required field and must be populated";
            }
            else if (searchVar[j].orcl_segment5 == undefined || searchVar[j].orcl_segment5 == null || searchVar[j].orcl_segment5 == "") {
              errorMessage = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
            }
            else if ((searchVar[j].orcl_segment5.toString().length != 9) || isNaN(searchVar[j].orcl_segment5)) {
              errorMessage = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
            }
            else if (searchVar[j].start_date_active == undefined || searchVar[j].start_date_active == null || searchVar[j].start_date_active == "") {
              errorMessage = "START DATE is a required field and must be populated";
            }
            else if (searchVar[j].interface_type == undefined || searchVar[j].interface_type == null || searchVar[j].interface_type == "") {
              errorMessage = "INTERFACE_TYPE is a required field and must be populated";
            }
            else if ((searchVar[j].start_date_active != undefined) && (searchVar[j].end_date_active != undefined) && (searchVar[j].end_date_active < searchVar[j].start_date_active)) {
              errorMessage = "END DATE cannot be prior to start date";
            }
          }

        }
      }
      if (searchVar[j].action == 'U') {
        if ((searchVar[j].description != undefined) && (searchVar[j].description != null) && (searchVar[j].description != "")) {
          if (searchVar[j].description.length > 240) {
            errorMessage = "DESCRIPTION can only be 240 positions long";
          }
        }
      }
    }
    return errorMessage;
  };

  /*Export data*/
  PageModule.prototype.downloadExcel = async function (data, mapper, action) {

    var today = new Date();
    var date = today.getDate() + '-' + (today.toLocaleString("en-US", { month: "short" })) + '-' + today.getFullYear();

    if (mapper == "ACCOUNT" || mapper == "MSIS ACCOUNT NUMBER" || mapper == "MCD_TRIRIGA_MAPPER") {
      var xlsHeader;
      var createXLSLFormatObj = [];
      if (action == 'F') {
        xlsHeader = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date", "Error Message"];
      } else {
        xlsHeader = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date"];
      }
      createXLSLFormatObj.push(xlsHeader);
      $.each(data, function (index, value) {
        var innerRowData = [];

        innerRowData.push((value.set_of_books_id === undefined) || (value.set_of_books_id === null) ? "" : value.set_of_books_id);
        innerRowData.push((value.set_of_books_name === undefined) || (value.set_of_books_name === null) ? "" : value.set_of_books_name);
        innerRowData.push((value.lookup_type === undefined) || (value.lookup_type === null) ? "" : value.lookup_type);
        innerRowData.push((value.lookup_code === undefined) || (value.lookup_code === null) ? "" : value.lookup_code);
        innerRowData.push((value.description === undefined) || (value.description === null) ? "" : value.description);
        innerRowData.push((value.orcl_segment1 === undefined) || (value.orcl_segment1 === null) ? "" : value.orcl_segment1);
        innerRowData.push((value.orcl_segment2 === undefined) || (value.orcl_segment2 === null) ? "" : value.orcl_segment2);
        innerRowData.push((value.orcl_segment3 === undefined) || (value.orcl_segment3 === null) ? "" : value.orcl_segment3);
        innerRowData.push((value.orcl_segment4 === undefined) || (value.orcl_segment4 === null) ? "" : value.orcl_segment4);
        innerRowData.push((value.orcl_segment5 === undefined) || (value.orcl_segment5 === null) ? "" : value.orcl_segment5);
        innerRowData.push((value.orcl_segment6 === undefined) || (value.orcl_segment6 === null) ? "" : value.orcl_segment6);
        innerRowData.push((value.orcl_segment7 === undefined) || (value.orcl_segment7 === null) ? "" : value.orcl_segment7);
        innerRowData.push((value.orcl_segment8 === undefined) || (value.orcl_segment8 === null) ? "" : value.orcl_segment8);
        innerRowData.push((value.lgcy_segment1 === undefined) || (value.lgcy_segment1 === null) ? "" : value.lgcy_segment1);
        innerRowData.push("");
        innerRowData.push("");
        innerRowData.push("");
        innerRowData.push((value.lgcy_segment5 === undefined) || (value.lgcy_segment5 === null) ? "" : value.lgcy_segment5);
        innerRowData.push((value.lgcy_segment6 === undefined) || (value.lgcy_segment6 === null) ? "" : value.lgcy_segment6);
        innerRowData.push((value.lgcy_segment7 === undefined) || (value.lgcy_segment7 === null) ? "" : value.lgcy_segment7);
        innerRowData.push((value.enable_flag === undefined) || (value.enable_flag === null) ? "" : value.enable_flag);
        if (value.start_date_active != undefined) {
          innerRowData.push((value.start_date_active === undefined) || (value.start_date_active === null) ? "" : value.start_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.start_date_active = "");
        }

        if (value.end_date_active != undefined) {
          innerRowData.push((value.end_date_active === undefined) || (value.end_date_active === null) ? "" : value.end_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.end_date_active = "");
        }
        innerRowData.push((value.attribute_category === undefined) || (value.attribute_category === null) ? "" : value.attribute_category);
        innerRowData.push((value.attribute1 === undefined) || (value.attribute1 === null) ? "" : value.attribute1);
        innerRowData.push((value.attribute2 === undefined) || (value.attribute2 === null) ? "" : value.attribute2);
        innerRowData.push((value.attribute3 === undefined) || (value.attribute3 === null) ? "" : value.attribute3);
        innerRowData.push((value.attribute4 === undefined) || (value.attribute4 === null) ? "" : value.attribute4);
        innerRowData.push((value.attribute5 === undefined) || (value.attribute5 === null) ? "" : value.attribute5);
        innerRowData.push((value.attribute6 === undefined) || (value.attribute6 === null) ? "" : value.attribute6);
        innerRowData.push((value.attribute7 === undefined) || (value.attribute7 === null) ? "" : value.attribute7);
        innerRowData.push((value.attribute8 === undefined) || (value.attribute8 === null) ? "" : value.attribute8);
        innerRowData.push((value.attribute9 === undefined) || (value.attribute9 === null) ? "" : value.attribute9);
        innerRowData.push((value.attribute10 === undefined) || (value.attribute10 === null) ? "" : value.attribute10);
        innerRowData.push((value.attribute11 === undefined) || (value.attribute11 === null) ? "" : value.attribute11);
        innerRowData.push((value.attribute12 === undefined) || (value.attribute12 === null) ? "" : value.attribute12);
        innerRowData.push((value.attribute13 === undefined) || (value.attribute13 === null) ? "" : value.attribute13);
        innerRowData.push((value.attribute14 === undefined) || (value.attribute14 === null) ? "" : value.attribute14);
        innerRowData.push((value.attribute15 === undefined) || (value.attribute15 === null) ? "" : value.attribute15);
        innerRowData.push((value.interface_type === undefined) || (value.interface_type === null) ? "" : value.interface_type);
        innerRowData.push((value.created_by === undefined) || (value.created_by === null) ? "" : value.created_by);
        if (value.creation_date != undefined) {
          innerRowData.push((value.creation_date === undefined) || (value.creation_date === null) ? "" : value.creation_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.creation_date = "");
        }
        innerRowData.push((value.last_update_login === undefined) || (value.last_update_login === null) ? "" : value.last_update_login);
        innerRowData.push((value.last_updated_by === undefined) || (value.last_updated_by === null) ? "" : value.last_updated_by);

        if (value.last_update_date) {
          innerRowData.push((value.last_update_date === undefined) || (value.last_update_date === null) ? "" : value.last_update_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.last_update_date = "");
        }
        if (action == 'F') {
          innerRowData.push((value.errmsg === undefined) || (value.errmsg === null) ? "" : value.errmsg);
        }
        createXLSLFormatObj.push(innerRowData);

      });

      var csv = "";
      for (let row of createXLSLFormatObj) {
        for (let col of row) { csv += col + ","; }
        csv += "\r\n";
      }
      var myBlob = new Blob([csv], { type: "text/csv" });
      const fileHandle = await window.showSaveFilePicker({
        suggestedName: mapper + " EXPORT " + date + ".csv",
        types: [{
          description: "csv file",
          accept: { "text/csv": [".csv"] }
        }]
      });
      const fileStream = await fileHandle.createWritable();
      if (fileStream.write(myBlob)) {
        fileStream.close();
        return true;
      } else {
        fileStream.close();
        return false;
      }
      //fileStream.write(myBlob);
      //fileStream.close();
    }

    if (mapper == "COMPANY") {
      var createXLSLFormatObjC = [];
      var xlsHeaderC;

      if (action == 'F') {
        xlsHeaderC = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date", "Error Message"];
      } else {
        xlsHeaderC = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date"];
      }
      createXLSLFormatObjC.push(xlsHeaderC);
      $.each(data, function (index, value) {
        var innerRowData = [];

        innerRowData.push((value.set_of_books_id === undefined) || (value.set_of_books_id === null) ? "" : value.set_of_books_id);
        innerRowData.push((value.set_of_books_name === undefined) || (value.set_of_books_name === null) ? "" : value.set_of_books_name);
        innerRowData.push((value.lookup_type === undefined) || (value.lookup_type === null) ? "" : value.lookup_type);
        innerRowData.push((value.lookup_code === undefined) || (value.lookup_code === null) ? "" : value.lookup_code);
        innerRowData.push((value.description === undefined) || (value.description === null) ? "" : value.description);
        innerRowData.push((value.orcl_segment1 === undefined) || (value.orcl_segment1 === null) ? "" : value.orcl_segment1);
        innerRowData.push((value.orcl_segment2 === undefined) || (value.orcl_segment2 === null) ? "" : value.orcl_segment2);
        innerRowData.push((value.orcl_segment3 === undefined) || (value.orcl_segment3 === null) ? "" : value.orcl_segment3);
        innerRowData.push((value.orcl_segment4 === undefined) || (value.orcl_segment4 === null) ? "" : value.orcl_segment4);
        innerRowData.push((value.orcl_segment5 === undefined) || (value.orcl_segment5 === null) ? "" : value.orcl_segment5);
        innerRowData.push((value.orcl_segment6 === undefined) || (value.orcl_segment6 === null) ? "" : value.orcl_segment6);
        innerRowData.push((value.orcl_segment7 === undefined) || (value.orcl_segment7 === null) ? "" : value.orcl_segment7);
        innerRowData.push((value.orcl_segment8 === undefined) || (value.orcl_segment8 === null) ? "" : value.orcl_segment8);
        innerRowData.push("");
        innerRowData.push((value.lgcy_segment1 === undefined) || (value.lgcy_segment1 === null) ? "" : value.lgcy_segment1);
        innerRowData.push("");
        innerRowData.push("");
        innerRowData.push((value.lgcy_segment5 === undefined) || (value.lgcy_segment5 === null) ? "" : value.lgcy_segment5);
        innerRowData.push((value.lgcy_segment6 === undefined) || (value.lgcy_segment6 === null) ? "" : value.lgcy_segment6);
        innerRowData.push((value.lgcy_segment7 === undefined) || (value.lgcy_segment7 === null) ? "" : value.lgcy_segment7);
        innerRowData.push((value.enable_flag === undefined) || (value.enable_flag === null) ? "" : value.enable_flag);
        if (value.start_date_active != undefined) {
          innerRowData.push((value.start_date_active === undefined) || (value.start_date_active === null) ? "" : value.start_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.start_date_active = "");
        }

        if (value.end_date_active != undefined) {
          innerRowData.push((value.end_date_active === undefined) || (value.end_date_active === null) ? "" : value.end_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.end_date_active = "");
        }
        innerRowData.push((value.attribute_category === undefined) || (value.attribute_category === null) ? "" : value.attribute_category);
        innerRowData.push((value.attribute1 === undefined) || (value.attribute1 === null) ? "" : value.attribute1);
        innerRowData.push((value.attribute2 === undefined) || (value.attribute2 === null) ? "" : value.attribute2);
        innerRowData.push((value.attribute3 === undefined) || (value.attribute3 === null) ? "" : value.attribute3);
        innerRowData.push((value.attribute4 === undefined) || (value.attribute4 === null) ? "" : value.attribute4);
        innerRowData.push((value.attribute5 === undefined) || (value.attribute5 === null) ? "" : value.attribute5);
        innerRowData.push((value.attribute6 === undefined) || (value.attribute6 === null) ? "" : value.attribute6);
        innerRowData.push((value.attribute7 === undefined) || (value.attribute7 === null) ? "" : value.attribute7);
        innerRowData.push((value.attribute8 === undefined) || (value.attribute8 === null) ? "" : value.attribute8);
        innerRowData.push((value.attribute9 === undefined) || (value.attribute9 === null) ? "" : value.attribute9);
        innerRowData.push((value.attribute10 === undefined) || (value.attribute10 === null) ? "" : value.attribute10);
        innerRowData.push((value.attribute11 === undefined) || (value.attribute11 === null) ? "" : value.attribute11);
        innerRowData.push((value.attribute12 === undefined) || (value.attribute12 === null) ? "" : value.attribute12);
        innerRowData.push((value.attribute13 === undefined) || (value.attribute13 === null) ? "" : value.attribute13);
        innerRowData.push((value.attribute14 === undefined) || (value.attribute14 === null) ? "" : value.attribute14);
        innerRowData.push((value.attribute15 === undefined) || (value.attribute15 === null) ? "" : value.attribute15);
        innerRowData.push((value.interface_type === undefined) || (value.interface_type === null) ? "" : value.interface_type);
        innerRowData.push((value.created_by === undefined) || (value.created_by === null) ? "" : value.created_by);
        if (value.creation_date != undefined) {
          innerRowData.push((value.creation_date === undefined) || (value.creation_date === null) ? "" : value.creation_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.creation_date = "");
        }
        innerRowData.push((value.last_update_login === undefined) || (value.last_update_login === null) ? "" : value.last_update_login);
        innerRowData.push((value.last_updated_by === undefined) || (value.last_updated_by === null) ? "" : value.last_updated_by);

        if (value.last_update_date) {
          innerRowData.push((value.last_update_date === undefined) || (value.last_update_date === null) ? "" : value.last_update_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.last_update_date = "");
        }
        if (action == 'F') {
          innerRowData.push((value.errmsg === undefined) || (value.errmsg === null) ? "" : value.errmsg);
        }
        createXLSLFormatObjC.push(innerRowData);

      });

      var csvC = "";
      for (let row of createXLSLFormatObjC) {
        for (let col of row) { csvC += col + ","; }
        csvC += "\r\n";
      }
      var myBlobC = new Blob([csvC], { type: "text/csv" });
      const fileHandle = await window.showSaveFilePicker({
        suggestedName: mapper + " EXPORT " + date + ".csv",
        types: [{
          description: "csv file",
          accept: { "text/csv": [".csv"] }
        }]
      });
      const fileStream = await fileHandle.createWritable();
      if (fileStream.write(myBlobC)) {
        fileStream.close();
        return true;
      } else {
        fileStream.close();
        return false;
      }
      //fileStream.write(myBlobC);
      //fileStream.close();
    }

    if (mapper == "DEPARTMENT") {
      var createXLSLFormatObjD = [];
      var xlsHeaderD;
      if (action == 'F') {
        xlsHeaderD = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date", "Error Message"];
      }
      else {
        xlsHeaderD = ["SET_OF_BOOKS_ID", "Ledger", "Mapper", "LOOKUP_CODE", "Description", "Company", "Line of Business", "Location", "HR Dept Cost Center", "Account Number", "Intercompany", "Future1", "Future2",
          "MSIS Account Number", "Company", "Main (Site/Dept)", "Sub (Site/Dept)", "MBS Global", "MBS Sub", "MBS Local", "Enable Flag", "Start Date", "End Date", "Attribute Category",
          "Attribute1", "MBS GBL", "MBS Intercompany", "Attribute4", "Attribute5", "Attribute6", "Attribute7", "Attribute8",
          "Attribute9", "Attribute10", "Attribute11", "Attribute12", "Attribute13", "Attribute14", "Attribute15", "Interface type", "Created By",
          "Creation Date", "Last Update Login", "Last Updated By", "Last Update Date"];
      }

      createXLSLFormatObjD.push(xlsHeaderD);
      $.each(data, function (index, value) {
        var innerRowData = [];

        innerRowData.push((value.set_of_books_id === undefined) || (value.set_of_books_id === null) ? "" : value.set_of_books_id);
        innerRowData.push((value.set_of_books_name === undefined) || (value.set_of_books_name === null) ? "" : value.set_of_books_name);
        innerRowData.push((value.lookup_type === undefined) || (value.lookup_type === null) ? "" : value.lookup_type);
        innerRowData.push((value.lookup_code === undefined) || (value.lookup_code === null) ? "" : value.lookup_code);
        innerRowData.push((value.description === undefined) || (value.description === null) ? "" : value.description);
        innerRowData.push((value.orcl_segment1 === undefined) || (value.orcl_segment1 === null) ? "" : value.orcl_segment1);
        innerRowData.push((value.orcl_segment2 === undefined) || (value.orcl_segment2 === null) ? "" : value.orcl_segment2);
        innerRowData.push((value.orcl_segment3 === undefined) || (value.orcl_segment3 === null) ? "" : value.orcl_segment3);
        innerRowData.push((value.orcl_segment4 === undefined) || (value.orcl_segment4 === null) ? "" : value.orcl_segment4);
        innerRowData.push((value.orcl_segment5 === undefined) || (value.orcl_segment5 === null) ? "" : value.orcl_segment5);
        innerRowData.push((value.orcl_segment6 === undefined) || (value.orcl_segment6 === null) ? "" : value.orcl_segment6);
        innerRowData.push((value.orcl_segment7 === undefined) || (value.orcl_segment7 === null) ? "" : value.orcl_segment7);
        innerRowData.push((value.orcl_segment8 === undefined) || (value.orcl_segment8 === null) ? "" : value.orcl_segment8);
        innerRowData.push("");
        innerRowData.push("");
        innerRowData.push((value.lgcy_segment1 === undefined) || (value.lgcy_segment1 === null) ? "" : value.lgcy_segment1);
        innerRowData.push((value.lgcy_segment2 === undefined) || (value.lgcy_segment2 === null) ? "" : value.lgcy_segment2);
        innerRowData.push((value.lgcy_segment5 === undefined) || (value.lgcy_segment5 === null) ? "" : value.lgcy_segment5);
        innerRowData.push((value.lgcy_segment6 === undefined) || (value.lgcy_segment6 === null) ? "" : value.lgcy_segment6);
        innerRowData.push((value.lgcy_segment7 === undefined) || (value.lgcy_segment7 === null) ? "" : value.lgcy_segment7);
        innerRowData.push((value.enable_flag === undefined) || (value.enable_flag === null) ? "" : value.enable_flag);
        if (value.start_date_active != undefined) {
          innerRowData.push((value.start_date_active === undefined) || (value.start_date_active === null) ? "" : value.start_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.start_date_active = "");
        }

        if (value.end_date_active != undefined) {
          innerRowData.push((value.end_date_active === undefined) || (value.end_date_active === null) ? "" : value.end_date_active.substring(0, 10));
        }
        else {
          innerRowData.push(value.end_date_active = "");
        }
        innerRowData.push((value.attribute_category === undefined) || (value.attribute_category === null) ? "" : value.attribute_category);
        innerRowData.push((value.attribute1 === undefined) || (value.attribute1 === null) ? "" : value.attribute1);
        innerRowData.push((value.attribute2 === undefined) || (value.attribute2 === null) ? "" : value.attribute2);
        innerRowData.push((value.attribute3 === undefined) || (value.attribute3 === null) ? "" : value.attribute3);
        innerRowData.push((value.attribute4 === undefined) || (value.attribute4 === null) ? "" : value.attribute4);
        innerRowData.push((value.attribute5 === undefined) || (value.attribute5 === null) ? "" : value.attribute5);
        innerRowData.push((value.attribute6 === undefined) || (value.attribute6 === null) ? "" : value.attribute6);
        innerRowData.push((value.attribute7 === undefined) || (value.attribute7 === null) ? "" : value.attribute7);
        innerRowData.push((value.attribute8 === undefined) || (value.attribute8 === null) ? "" : value.attribute8);
        innerRowData.push((value.attribute9 === undefined) || (value.attribute9 === null) ? "" : value.attribute9);
        innerRowData.push((value.attribute10 === undefined) || (value.attribute10 === null) ? "" : value.attribute10);
        innerRowData.push((value.attribute11 === undefined) || (value.attribute11 === null) ? "" : value.attribute11);
        innerRowData.push((value.attribute12 === undefined) || (value.attribute12 === null) ? "" : value.attribute12);
        innerRowData.push((value.attribute13 === undefined) || (value.attribute13 === null) ? "" : value.attribute13);
        innerRowData.push((value.attribute14 === undefined) || (value.attribute14 === null) ? "" : value.attribute14);
        innerRowData.push((value.attribute15 === undefined) || (value.attribute15 === null) ? "" : value.attribute15);
        innerRowData.push((value.interface_type === undefined) || (value.interface_type === null) ? "" : value.interface_type);
        innerRowData.push((value.created_by === undefined) || (value.created_by === null) ? "" : value.created_by);
        if (value.creation_date != undefined) {
          innerRowData.push((value.creation_date === undefined) || (value.creation_date === null) ? "" : value.creation_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.creation_date = "");
        }
        innerRowData.push((value.last_update_login === undefined) || (value.last_update_login === null) ? "" : value.last_update_login);
        innerRowData.push((value.last_updated_by === undefined) || (value.last_updated_by === null) ? "" : value.last_updated_by);

        if (value.last_update_date) {
          innerRowData.push((value.last_update_date === undefined) || (value.last_update_date === null) ? "" : value.last_update_date.substring(0, 10));
        }
        else {
          innerRowData.push(value.last_update_date = "");
        }
        if (action == 'F') {
          innerRowData.push((value.errmsg === undefined) || (value.errmsg === null) ? "" : value.errmsg);
        }
        createXLSLFormatObjD.push(innerRowData);

      });

      var csvD = "";
      for (let row of createXLSLFormatObjD) {
        for (let col of row) { csvD += col + ","; }
        csvD += "\r\n";
      }
      var myBlobD = new Blob([csvD], { type: "text/csv" });
      const fileHandle = await window.showSaveFilePicker({
        suggestedName: mapper + " EXPORT " + date + ".csv",
        types: [{
          description: "csv file",
          accept: { "text/csv": [".csv"] }
        }]
      });
      const fileStream = await fileHandle.createWritable();
      if (fileStream.write(myBlobD)) {
        fileStream.close();
        return true;
      } else {
        fileStream.close();
        return false;
      }
      //fileStream.write(myBlobD);
      //fileStream.close();
    }

  };


  /* download export template */
  PageModule.prototype.downloadExcelTemplate = async function (mapper, ledger) {

    var today = new Date();
    var date = today.getDate() + '-' + (today.toLocaleString("en-US", { month: "short" })) + '-' + today.getFullYear();

    if (mapper == "ACCOUNT") {
      var createXLSLFormatObj1 = [];
      var ledgerArrA = ["Ledger", ledger];
      var mapperArrA = ["Mapper", mapper];

      createXLSLFormatObj1.push(ledgerArrA);
      createXLSLFormatObj1.push(mapperArrA);
      var xlsHeader = ["Description(alphanumeric maxlength=240)", "Line of Business(3 numeric positions)",
        "Account Number(9 numeric positions)", "MSIS Account Number(9 numeric positions)", "Start Date(DD-MM-YYYY)",
        "End Date(DD-MM-YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];
      createXLSLFormatObj1.push(xlsHeader);
      
    /*
      var csv = "";
      for (let row of createXLSLFormatObj1) {
        for (let col of row) { csv += col + ","; }
        csv += "\r\n";
      }
      var myBlob = new Blob([csv], { type: "text/csv" });
      const fileHandle = await window.showSaveFilePicker({
        suggestedName: ledger + " " + mapper + " " + "Mapper Template" + " " + date + ".csv",
        types: [{
          description: "csv file",
          accept: { "text/csv": [".csv"] }
        }]
      });
      const fileStream = await fileHandle.createWritable();
      fileStream.write(myBlob);
      fileStream.close();

      */
       var workbook = XLSX.utils.book_new();
      // create a new worksheet
      var worksheet = XLSX.utils.aoa_to_sheet(createXLSLFormatObj1);
      // add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
      // generate the Excel file data
      var fileData = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
      // create a Blob object from the file data
      var blob = new Blob([fileData], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
     /* if(blob.size > 0){
        exportFlag ="Account Mapper template was successfully exported";
      }*/
      window.showSaveFilePicker({
        suggestedName: ledger + " " + mapper + " Mapper Template " + date + ".xlsx",
        types: [
          { description: 'Excel 2007+ (XLSX)', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] } },
          { description: 'Excel 97-2004 (XLS)', accept: { 'application/vnd.ms-excel': ['.xls'] } },
          { description: 'Excel 2007+ Binary (XLSB)', accept: { 'application/vnd.ms-excel.sheet.binary.macroEnabled.12': ['.xlsb'] } },
          
        ]
      }).then(function (fileHandle) {
        fileHandle.createWritable().then(function (fileWritable) {
          fileWritable.write(blob).then(function () {
            fileWritable.close();            
          });        
        });      
      }).then(function(showAlert){
        var exportMsgA = "Account Mapper template was successfully exported";
        alert (exportMsgA);
    });
    }
    if (mapper == "COMPANY") {
      var createXLSLFormatObj2 = [];
      var ledgerArrC = ["Ledger", ledger];
      var mapperArrC = ["Mapper", mapper];

      createXLSLFormatObj2.push(ledgerArrC);
      createXLSLFormatObj2.push(mapperArrC);

      var xlsHeaderC = ["Description(alphanumeric maxlength=240)", "Company(5 alphanumeric positions)",
        "Legacy Company(3 numeric positions)", "Start Date(DD-MM-YYYY)", "End Date(DD-MM-YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];
      createXLSLFormatObj2.push(xlsHeaderC);
      var workbookC = XLSX.utils.book_new();
      // create a new worksheet
      var worksheetC = XLSX.utils.aoa_to_sheet(createXLSLFormatObj2);
      // add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbookC, worksheetC, "Sheet1");
      // generate the Excel file data
      var fileDataC = XLSX.write(workbookC, { bookType: 'xlsx', type: 'array' });
      // create a Blob object from the file data
      var myBlobC = new Blob([fileDataC], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
     
      window.showSaveFilePicker({
        suggestedName: ledger + " " + mapper + " Mapper Template " + date + ".xlsx",
        types: [
          { description: 'Excel 2007+ (XLSX)', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] } },
          { description: 'Excel 97-2004 (XLS)', accept: { 'application/vnd.ms-excel': ['.xls'] } },
          { description: 'Excel 2007+ Binary (XLSB)', accept: { 'application/vnd.ms-excel.sheet.binary.macroEnabled.12': ['.xlsb'] } },
          
        ]
      }).then(function (fileHandle) {
        fileHandle.createWritable().then(function (fileWritable) {
          fileWritable.write(myBlobC).then(function () {
            fileWritable.close();            
          });        
        });      
      }).then(function(showAlert){
        var exportMsgC = "Company Mapper template was successfully exported";
        alert (exportMsgC);
    });
    }
    if (mapper == "DEPARTMENT") {
      var createXLSLFormatObj3 = [];
      var ledgerArrD = ["Ledger", ledger];
      var mapperArrD = ["Mapper", mapper];

      createXLSLFormatObj3.push(ledgerArrD);
      createXLSLFormatObj3.push(mapperArrD);
      var xlsHeaderD = ["Description(alphanumeric maxlength=240)",
        "Company(5 alphanumeric positions)", "Location(8 numeric positions)", "HR Dept Cost Center(5 numeric positions)",
        "Main(Site/Dept)(8 numeric positions)", "Sub(Site/Dept)(1 numeric positions)",
        "Start Date(DD-MM-YYYY)", "End Date(DD-MM-YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      createXLSLFormatObj3.push(xlsHeaderD);
       var workbookD = XLSX.utils.book_new();
      // create a new worksheet
      var worksheetD = XLSX.utils.aoa_to_sheet(createXLSLFormatObj3);
      // add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbookD, worksheetD, "Sheet1");
      // generate the Excel file data
      var fileDataD = XLSX.write(workbookD, { bookType: 'xlsx', type: 'array' });
      // create a Blob object from the file data
      var myBlobD = new Blob([fileDataD], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
     /* if(blob.size > 0){
        exportFlag ="Account Mapper template was successfully exported";
      }*/
      window.showSaveFilePicker({
        suggestedName: ledger + " " + mapper + " Mapper Template " + date + ".xlsx",
        types: [
          { description: 'Excel 2007+ (XLSX)', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] } },
          { description: 'Excel 97-2004 (XLS)', accept: { 'application/vnd.ms-excel': ['.xls'] } },
          { description: 'Excel 2007+ Binary (XLSB)', accept: { 'application/vnd.ms-excel.sheet.binary.macroEnabled.12': ['.xlsb'] } },
          
        ]
      }).then(function (fileHandle) {
        fileHandle.createWritable().then(function (fileWritable) {
          fileWritable.write(myBlobD).then(function () {
            fileWritable.close();            
          });        
        });      
      }).then(function(showAlert){
        var exportMsgD = "Department Mapper template was successfully exported";
        alert (exportMsgD);
    });
    }

    if (mapper == "MSIS ACCOUNT NUMBER") {
      var createXLSLFormatObj4 = [];
      var ledgerArrM = ["Ledger", ledger];
      var mapperArrM = ["Mapper", mapper];

      createXLSLFormatObj4.push(ledgerArrM);
      createXLSLFormatObj4.push(mapperArrM);
      var xlsHeaderM = ["Description(alphanumeric maxlength=240)", "MSIS Account Number(9 numeric positions)", "Start Date(DD-MM-YYYY)",
        "End Date(DD-MM-YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      createXLSLFormatObj4.push(xlsHeaderM);
      var workbook4 = XLSX.utils.book_new();
      // create a new worksheet
      var worksheet4 = XLSX.utils.aoa_to_sheet(createXLSLFormatObj4);
      // add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbook4, worksheet4, "Sheet1");
      // generate the Excel file data
      var fileData4 = XLSX.write(workbook4, { bookType: 'xlsx', type: 'array' });
      // create a Blob object from the file data
      var blob4 = new Blob([fileData4], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
     /* if(blob.size > 0){
        exportFlag ="Account Mapper template was successfully exported";
      }*/
      window.showSaveFilePicker({
        suggestedName: ledger + " MSIS Account Number Mapper Template " + date + ".xlsx",
        types: [
          { description: 'Excel 2007+ (XLSX)', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] } },
          { description: 'Excel 97-2004 (XLS)', accept: { 'application/vnd.ms-excel': ['.xls'] } },
          { description: 'Excel 2007+ Binary (XLSB)', accept: { 'application/vnd.ms-excel.sheet.binary.macroEnabled.12': ['.xlsb'] } },
          
        ]
      }).then(function (fileHandle) {
        fileHandle.createWritable().then(function (fileWritable) {
          fileWritable.write(blob4).then(function () {
            fileWritable.close();            
          });        
        });      
      }).then(function(showAlert){
        var exportMsgM = "MSIS Account Number Mapper template was successfully exported";
        alert (exportMsgM);
    });
    }
    if (mapper == "MCD_TRIRIGA_MAPPER") {
      var createXLSLFormatObj5 = [];
      var ledgerArrT = ["Ledger", ledger];
      var mapperArrT = ["Mapper", mapper];

      createXLSLFormatObj5.push(ledgerArrT);
      createXLSLFormatObj5.push(mapperArrT);
      var xlsHeaderT = ["Lookup(alphanumeric maxlength=240)", "Description(alphanumeric maxlength=240)", "Line of Business(3 numeric positions)",
        "Account Number(9 numeric positions)", "Start Date(DD-MM-YYYY)",
        "End Date(DD-MM-YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];
      createXLSLFormatObj5.push(xlsHeaderT);
      var workbookT = XLSX.utils.book_new();
      // create a new worksheet
      var worksheetT = XLSX.utils.aoa_to_sheet(createXLSLFormatObj5);
      // add the worksheet to the workbook
      XLSX.utils.book_append_sheet(workbookT, worksheetT, "Sheet1");
      // generate the Excel file data
      var fileDataT = XLSX.write(workbookT, { bookType: 'xlsx', type: 'array' });
      // create a Blob object from the file data
      var myBlobT = new Blob([fileDataT], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
     /* if(blob.size > 0){
        exportFlag ="Account Mapper template was successfully exported";
      }*/
      window.showSaveFilePicker({
        suggestedName: ledger + " " + mapper + " Mapper Template " + date + ".xlsx",
        types: [
          { description: 'Excel 2007+ (XLSX)', accept: { 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet': ['.xlsx'] } },
          { description: 'Excel 97-2004 (XLS)', accept: { 'application/vnd.ms-excel': ['.xls'] } },
          { description: 'Excel 2007+ Binary (XLSB)', accept: { 'application/vnd.ms-excel.sheet.binary.macroEnabled.12': ['.xlsb'] } },
          
        ]
      }).then(function (fileHandle) {
        fileHandle.createWritable().then(function (fileWritable) {
          fileWritable.write(myBlobT).then(function () {
            fileWritable.close();            
          });        
        });      
      }).then(function(showAlert){
        var exportMsgT = "MCD_TRIRIGA_MAPPER Mapper template was successfully exported";
        alert (exportMsgT);
    });
    }
  };

  /* data value check for date(changing to ISO format), enable_flag(assigning value), createdby(appuser - assigning value) before saving to DB */
  PageModule.prototype.dataValueCheckbeforeSAVE = function (recArr, appUser) {

    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    var today = now.getFullYear() + "-" + (month) + "-" + (day);
    var hours = ("0" + now.getHours()).slice(-2);
    var minutes = ("0" + now.getMinutes()).slice(-2);
    var start_date;
    var end_date;
    console.log(today);

    var isoDate2 = today + "T"+ hours +":"+ minutes +":00Z";

    for (var j = 0; j < recArr.length; j++) {

      if (recArr[j].action == 'U') {
        recArr[j].last_update_login = appUser;
        recArr[j].last_updated_by = appUser;
        recArr[j].last_update_date = isoDate2;
      }

      /*code for changing end_date_active,start_date_active to ISO date format (for "U","I","F" - as end date is editable in all three cases)*/
      if (recArr[j].action == 'I' || recArr[j].action == 'F' || recArr[j].action == 'U') {
        if (recArr[j].end_date_active != undefined && recArr[j].end_date_active != null && recArr[j].end_date_active != "") {

          var date = new Date(recArr[j].end_date_active);
          var now_utc = Date.UTC(date.getUTCFullYear(), date.getUTCMonth(),
            date.getUTCDate(), date.getUTCHours(),
            date.getUTCMinutes(), date.getUTCSeconds());

          console.log(new Date(now_utc));
          console.log(date.toISOString());

          var isoDate = date.toISOString();
          recArr[j].end_date_active = isoDate;

          end_date = recArr[j].end_date_active.substring(0, 10);


          /*var offset = new Date().getTimezoneOffset();// getting offset to make time in gmt+0 zone (UTC) (for gmt+5 offset comes as -300 minutes)
          var date = new Date(recArr[j].end_date_active);
          date.setMinutes ( date.getMinutes() + offset);// date now in UTC time
   
          var utc = date.toUTCString();
          var utcDate = new Date(date);
          var isoDate = utcDate.toISOString(); */

        }
        /*code for changing end_date_active to ISO date format end */


        /*code for changing start_date_active to ISO date format (for "I" and "F" - as start date is editable only in case of insert and file upload) */
        if (recArr[j].start_date_active != undefined && recArr[j].start_date_active != null && recArr[j].start_date_active != "") {

          var date1 = new Date(recArr[j].start_date_active);
          var now_utc1 = Date.UTC(date1.getUTCFullYear(), date1.getUTCMonth(),
            date1.getUTCDate(), date1.getUTCHours(),
            date1.getUTCMinutes(), date1.getUTCSeconds());

          console.log(new Date(now_utc1));
          console.log(date1.toISOString());

          var isoDate1 = date1.toISOString();
          recArr[j].start_date_active = isoDate1;

          start_date = recArr[j].start_date_active.substring(0, 10);
        }
        /* code for changing start_date_active to ISO date format end */
      }


      if (recArr[j].action == 'I' || recArr[j].action == 'F') {
        recArr[j].created_by = appUser;
        recArr[j].creation_date = isoDate2;
        recArr[j].last_update_login = appUser;
        recArr[j].last_updated_by = appUser;
        recArr[j].last_update_date = isoDate2;


        if (start_date == today && recArr[j].end_date_active == undefined) {
          recArr[j].enable_flag = 'Y'; //d
        }
        else if (start_date == today && end_date < today) {
          recArr[j].enable_flag = 'Y'; // condition will never happen
        }
        else if (start_date == today && end_date == today) {
          recArr[j].enable_flag = 'N'; //d
        }
        else if (start_date == today && end_date > today) {
          recArr[j].enable_flag = 'Y'; //d
        }
        else if (start_date > today && recArr[j].end_date_active == undefined) {
          recArr[j].enable_flag = 'N'; //d
        }
        else if (start_date > today && end_date < today) {
          recArr[j].enable_flag = 'N'; //condition will never happen
        }
        else if (start_date > today && end_date == today) {
          recArr[j].enable_flag = 'Y';
        }
        else if (start_date > today && end_date > today) {
          recArr[j].enable_flag = 'N'; //d
        }
        else if (start_date < today && recArr[j].end_date_active == undefined) {
          recArr[j].enable_flag = 'Y'; //d
        }
        else if (start_date < today && end_date < today) {
          recArr[j].enable_flag = 'N'; //d
        }
        else if (start_date < today && end_date > today) {
          recArr[j].enable_flag = 'Y';  //d
        }
        else if (start_date < today && end_date == today) {
          recArr[j].enable_flag = 'N';  //d
        }
      }
    }
    return recArr;
  };


  PageModule.prototype.checkfile = function (sender) {
    var validExts = new Array(".xlsx", ".xls", ".csv");
    var fileExt = sender;
    fileExt = fileExt.substring(fileExt.lastIndexOf('.'));
    if (validExts.indexOf(fileExt) < 0) {
      // alert("Invalid file selected, valid files are of " +
      //         validExts.toString() + " types.");
      return false;
    }
    else return true;
  };


  PageModule.prototype.processfile = function (fileSet) {
    var reader = new FileReader();
    return new Promise(function (resolve, reject) {
      var reader = new FileReader();

      reader.onloadend = function (e) {
        var data = e.target.result;
        var workbook = XLSX.read(data, { type: 'binary' });
        var first_worksheet = workbook.Sheets[workbook.SheetNames[0]];
        var jsonArr = XLSX.utils.sheet_to_json(first_worksheet, { header: 1 });
        resolve(jsonArr);
      };
      reader.readAsBinaryString(fileSet[0]);
    });
  };


  PageModule.prototype.populateData = function (jsonArr) {
    var x = [];
    var ledger = jsonArr[0][1];
    var mapper = jsonArr[1][1];
    var headerArray, j, i, obj, objName, objValue;

    if (mapper == "COMPANY") {
      headerArray = ["description", "orcl_segment1", "lgcy_segment1", "start_date_active", "end_date_active", "interface_type"];

      for (j = 3; j < jsonArr.length; j++) {
        obj = {};
        for (i = 0; i < jsonArr[2].length; i++) {
          objName = headerArray[i];
          objValue = jsonArr[j][i];

          obj[objName] = objValue;
        }
        x.push(obj);
      }
    }
    if (mapper == "ACCOUNT") {
      headerArray = ["description", "orcl_segment2", "orcl_segment5", "lgcy_segment1", "start_date_active", "end_date_active", "interface_type"];

      for (j = 3; j < jsonArr.length; j++) {
        obj = {};
        for (i = 0; i < jsonArr[2].length; i++) {
          objName = headerArray[i];
          objValue = jsonArr[j][i];

          obj[objName] = objValue;

        }
        x.push(obj);
      }
    }
    if (mapper == "DEPARTMENT") {
      headerArray = ["description", "orcl_segment1", "orcl_segment3", "orcl_segment4", "lgcy_segment1", "lgcy_segment2", "start_date_active", "end_date_active", "interface_type"];

      for (j = 3; j < jsonArr.length; j++) {
        obj = {};
        for (i = 0; i < jsonArr[2].length; i++) {
          objName = headerArray[i];
          objValue = jsonArr[j][i];

          obj[objName] = objValue;

        }
        x.push(obj);
      }
    }
    if (mapper == "MSIS ACCOUNT NUMBER") {
      headerArray = ["description", "lgcy_segment1", "start_date_active", "end_date_active", "interface_type"];

      for (j = 3; j < jsonArr.length; j++) {
        obj = {};
        for (i = 0; i < jsonArr[2].length; i++) {
          objName = headerArray[i];
          objValue = jsonArr[j][i];

          obj[objName] = objValue;

        }
        x.push(obj);
      }
    }
    if (mapper == "MCD_TRIRIGA_MAPPER") {
      headerArray = ["lookup_code", "description", "orcl_segment2", "orcl_segment5", "start_date_active", "end_date_active", "interface_type"];

      for (j = 3; j < jsonArr.length; j++) {
        obj = {};
        for (i = 0; i < jsonArr[2].length; i++) {
          objName = headerArray[i];
          objValue = jsonArr[j][i];

          obj[objName] = objValue;

        }
        x.push(obj);
      }
    }
    return x;
  };

  /*import records validations before showing the records in UI*/
  PageModule.prototype.validateRecords = function (jsonArr, ledger, mapper, lineOfBusinessLov, accountNoLov, companyLov, locationLov, hrDepartmentLov, lookupcodeLov, descriptionLov, attri1) {

    var flag = "", errmsg = "";
    var lineOfBusiness, acctNo, msisAcctNo;
    var dT, date, dt2, isoDate, start_date;
    var nextIdValue;
    var newId = 0;
    var date1, datearray, newdate, startDate1, endDate1;

    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    var today = now.getFullYear() + "-" + (month) + "-" + (day);

    var pattern = /^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:(0[1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;   // 25/09/2022  
    var pattern1 = /^(0[1-9]|[12][0-9]|3[01])[\- \/.](?:([1-9]|1[012])[\- \/.](19|20)[0-9]{2})$/;   // 25/9/2022 

    for (var j = 0; j < jsonArr.length; j++) {

      jsonArr[j].lookup_type = mapper;
      jsonArr[j].set_of_books_name = ledger;
      jsonArr[j].attribute1 = attri1;
      jsonArr[j].action = "F";

      /*unique id  */
      if (nextIdValue === undefined) {
        for (var i = 0; i < jsonArr.length; i++) {
          newId = i;
        }
        nextIdValue = newId;
        jsonArr.forEach(s => {
          if (s.mapper_id > nextIdValue) nextIdValue = s.mapper_id;
        });
      }
      ++nextIdValue;
      jsonArr[j].mapper_id = nextIdValue;
      /*code for unique id end. */


      /*converting binary date to gregorian */
      if (jsonArr[j].start_date_active != undefined) {

        console.log(pattern.test(jsonArr[j].start_date_active));
        console.log(pattern1.test(jsonArr[j].start_date_active));

        if ((pattern.test(jsonArr[j].start_date_active) == true) || (pattern1.test(jsonArr[j].start_date_active) == true)) {
          date1 = jsonArr[j].start_date_active;
          datearray = date1.split("/");
          newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
          date = new Date(newdate);
        }
        else {
          dT = new Date(((jsonArr[j].start_date_active) - (25567 + 1)) * 86400 * 1000);
          date = ((dT.getMonth() + 1) + '/' + dT.getDate()) + '/' + (dT.getFullYear());
        }

        dt2 = new Date(date);
        isoDate = dt2.toISOString();
        startDate1 = isoDate.substring(0, 10);
        jsonArr[j].start_date_active = startDate1;
      }

      if (jsonArr[j].end_date_active != undefined) {

        console.log(pattern.test(jsonArr[j].end_date_active));
        console.log(pattern1.test(jsonArr[j].end_date_active));

        if ((pattern.test(jsonArr[j].end_date_active) == true) || (pattern1.test(jsonArr[j].end_date_active) == true)) {
          date1 = jsonArr[j].end_date_active;
          datearray = date1.split("/");
          newdate = datearray[1] + '/' + datearray[0] + '/' + datearray[2];
          date = new Date(newdate);
        }
        else {
          dT = new Date(((jsonArr[j].end_date_active) - (25567 + 1)) * 86400 * 1000);
          date = ((dT.getMonth() + 1) + '/' + dT.getDate()) + '/' + (dT.getFullYear());
        }

        dt2 = new Date(date);
        isoDate = dt2.toISOString();
        jsonArr[j].end_date_active = isoDate;
        endDate1 = isoDate.substring(0, 10);
        jsonArr[j].end_date_active = endDate1;
      }
      /*code for converting binary to gregorian end. */


      if (mapper == "ACCOUNT") {
        let lobarr = lineOfBusinessLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment2);
        console.log(lobarr);

        let accountNoarr = accountNoLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment5);
        console.log(accountNoarr);
		//PRB9023639
		//let test = jsonArr[j].lgcy_segment1.toString().length;
		//let temp = jsonArr[j].lgcy_segment1.toString();
		//let data = /^\d+$/.test(jsonArr[j].lgcy_segment1;
		//console.log("TESTCASE");
        //console.log(test);
		//console.log(temp);
		//console.log(data);

        if (jsonArr[j].description == undefined || jsonArr[j].description == null || jsonArr[j].description == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr[j].description.length > 240) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr[j].orcl_segment2 == undefined) || (jsonArr[j].orcl_segment2 == null) || (jsonArr[j].orcl_segment2 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT2 (Line of Business) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment2 != undefined) && (jsonArr[j].orcl_segment2 != null) && ((jsonArr[j].orcl_segment2.toString().length != 3) || (/^\d+$/.test(jsonArr[j].orcl_segment2) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT2 (Line of Business) must be 3 positions long and numeric";
        }
        else if (lobarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT2 (Line of Business)";
        }
        else if ((jsonArr[j].orcl_segment5 == undefined) || (jsonArr[j].orcl_segment5 == null) || (jsonArr[j].orcl_segment5 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment5 != undefined) && (jsonArr[j].orcl_segment5 != null) && ((jsonArr[j].orcl_segment5.toString().length != 9) || (/^\d+$/.test(jsonArr[j].orcl_segment5) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
        }
        else if (accountNoarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT5 (Account Number)";
        }
        else if ((jsonArr[j].lgcy_segment1 == undefined) || (jsonArr[j].lgcy_segment1 == null) || (jsonArr[j].lgcy_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
        }
		// New changes to modify lgcy_segment1 length to 9 PRB9023639
	// else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && ((jsonArr[j].lgcy_segment1.toString().length != 7)
      //else if (jsonArr[j].lgcy_segment1.toString().length > 9) 
		  else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && (jsonArr[j].lgcy_segment1.toString().length > 9) ) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account 37#) must be 9 positions long";
		 // console.log("TESTCASE1");
        //console.log(test);
		//console.log(temp);
		//console.log(data);
        }
		else if ((/^\d+$/.test(jsonArr[j].lgcy_segment1)) == false) {
			jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account 37#) must be Numeric";
		  //console.log("TESTCASE2");
		}  
        else if (jsonArr[j].start_date_active == undefined || jsonArr[j].start_date_active == null || jsonArr[j].start_date_active == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr[j].start_date_active != undefined) && (jsonArr[j].start_date_active != null) && (jsonArr[j].start_date_active != "") && (jsonArr[j].start_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < jsonArr[j].start_date_active.substring(0, 10))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr[j].interface_type == undefined || jsonArr[j].interface_type == null || jsonArr[j].interface_type == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr[j].interface_type != undefined) && (jsonArr[j].interface_type != null) && (jsonArr[j].interface_type != "I") && (jsonArr[j].interface_type != "O")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }


        else {
          jsonArr[j].flag = "true";
          jsonArr[j].errmsg = "";
        }
      }

      if (mapper == "COMPANY") {
        let companyarr = companyLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment1);
        console.log(companyLov);
        console.log(/^[A-Z0-9]*$/.test(jsonArr[j].orcl_segment1));  //testing alphanumeric


        if (jsonArr[j].description == undefined || jsonArr[j].description == null || jsonArr[j].description == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr[j].description.length > 240) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr[j].orcl_segment1 == undefined) || (jsonArr[j].orcl_segment1 == null) || (jsonArr[j].orcl_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment1 != undefined) && (jsonArr[j].orcl_segment1 != null) && (jsonArr[j].orcl_segment1.toString().length != 5)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT1 (Company) must be 5 positions long and alphanumeric";
        }
        else if ((companyarr <= 0) || (/^[A-Z0-9]*$/.test(jsonArr[j].orcl_segment1) == false)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT1 (Company)";
        }
        else if ((jsonArr[j].lgcy_segment1 == undefined) || (jsonArr[j].lgcy_segment1 == null) || (jsonArr[j].lgcy_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT2 (Company) is a required field and must be populated";
        }
        else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && ((jsonArr[j].lgcy_segment1.toString().length != 3) || (/^\d+$/.test(jsonArr[j].lgcy_segment1) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT2 (Company) must be 3 positions long and numeric";
        }

        else if (jsonArr[j].start_date_active == undefined || jsonArr[j].start_date_active == null || jsonArr[j].start_date_active == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr[j].start_date_active != undefined) && (jsonArr[j].start_date_active != null) && (jsonArr[j].start_date_active != "") && (jsonArr[j].start_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < jsonArr[j].start_date_active.substring(0, 10))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr[j].interface_type == undefined || jsonArr[j].interface_type == null || jsonArr[j].interface_type == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr[j].interface_type != undefined) && (jsonArr[j].interface_type != null) && (jsonArr[j].interface_type != "I") && (jsonArr[j].interface_type != "O")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }

        else {
          jsonArr[j].flag = "true";
          jsonArr[j].errmsg = "";
        }
      }

      if (mapper == "DEPARTMENT") {
        let companyarr = companyLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment1);
        console.log(companyLov);

        let locationarr = locationLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment3);
        console.log(locationarr);

        let hrDeptCostCentrearr = hrDepartmentLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment4);
        console.log(hrDeptCostCentrearr);

        if (jsonArr[j].description == undefined || jsonArr[j].description == null || jsonArr[j].description == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr[j].description.length > 240) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr[j].orcl_segment1 == undefined) || (jsonArr[j].orcl_segment1 == null) || (jsonArr[j].orcl_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment1 != undefined) && (jsonArr[j].orcl_segment1 != null) && (jsonArr[j].orcl_segment1.toString().length != 5)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT1 (Company) must be 5 positions long and alphanumeric";
        }
        else if ((companyarr <= 0) || (/^[A-Z0-9]*$/.test(jsonArr[j].orcl_segment1) == false)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT1 (Company)";
        }
        else if ((jsonArr[j].orcl_segment3 == undefined) || (jsonArr[j].orcl_segment3 == null) || (jsonArr[j].orcl_segment3 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT3 (Location) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment3 != undefined) && (jsonArr[j].orcl_segment3 != null) && ((jsonArr[j].orcl_segment3.toString().length != 8) || (/^\d+$/.test(jsonArr[j].orcl_segment3) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT3 (Location) must be 8 positions long and numeric";
        }
        else if (locationarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT3 (Location)";
        }
        else if ((jsonArr[j].orcl_segment4 == undefined) || (jsonArr[j].orcl_segment4 == null) || (jsonArr[j].orcl_segment4 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT4 (HR Dept Cost Center) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment4 != undefined) && (jsonArr[j].orcl_segment4 != null) && ((jsonArr[j].orcl_segment4.toString().length != 5) || (/^\d+$/.test(jsonArr[j].orcl_segment4) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT4 (HR Dept Cost Center) must be 5 positions long and numeric";
        }
        else if (hrDeptCostCentrearr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT4 (HR Dept Cost Center)";
        }
        else if ((jsonArr[j].lgcy_segment1 == undefined) || (jsonArr[j].lgcy_segment1 == null) || (jsonArr[j].lgcy_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT3 (Main (Site/Dept)) is a required field and must be populated";
        }
        // changed the condtion from (jsonArr[j].lgcy_segment1.toString().length != 8) to (jsonArr[j].lgcy_segment1.toString().length > 8) 
        else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && ((jsonArr[j].lgcy_segment1.toString().length > 8) || (/^\d+$/.test(jsonArr[j].lgcy_segment1) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT3 (Main (Site/Dept)) must be 8 positions long and numeric";
        }
      //  else if ((jsonArr[j].lgcy_segment2 == undefined) || (jsonArr[j].lgcy_segment2 == null) || (jsonArr[j].lgcy_segment2 == "")) {
       //   jsonArr[j].flag = "false";
       //   jsonArr[j].errmsg = "LGCY_SEGMENT4 (Sub (Site/Dept)) is a required field and must be populated";
       // }
        // changed the condtion from (jsonArr[j].lgcy_segment2.toString().length != 2) to (jsonArr[j].lgcy_segment2.toString().length > 2) 
		// New changes to modify lgcy_segment2 length to 1  PRB9023639
        else if ((jsonArr[j].lgcy_segment2 != undefined) && (jsonArr[j].lgcy_segment2 != null) && ((jsonArr[j].lgcy_segment2.toString().length > 1) || (/^\d+$/.test(jsonArr[j].lgcy_segment2) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT4 (Sub (Site/Dept)) must be 1 position long and numeric";
        }

        else if (jsonArr[j].start_date_active == undefined || jsonArr[j].start_date_active == null || jsonArr[j].start_date_active == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr[j].start_date_active != undefined) && (jsonArr[j].start_date_active != null) && (jsonArr[j].start_date_active != "") && (jsonArr[j].start_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < jsonArr[j].start_date_active.substring(0, 10))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr[j].interface_type == undefined || jsonArr[j].interface_type == null || jsonArr[j].interface_type == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr[j].interface_type != undefined) && (jsonArr[j].interface_type != null) && (jsonArr[j].interface_type != "I") && (jsonArr[j].interface_type != "O")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }
        else {
          jsonArr[j].flag = "true";
          jsonArr[j].errmsg = "";
        }
      }
      if (mapper == "MSIS ACCOUNT NUMBER") {

        if (jsonArr[j].description == undefined || jsonArr[j].description == null || jsonArr[j].description == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr[j].description.length > 240) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr[j].lgcy_segment1 == undefined) || (jsonArr[j].lgcy_segment1 == null) || (jsonArr[j].lgcy_segment1 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
        }
		// New changes to modify lgcy_segment1 length to 9 PRB9023639
		// else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && ((jsonArr[j].lgcy_segment1.toString().length != 7)
           else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && (jsonArr[j].lgcy_segment1.toString().length > 9) ) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be 9 positions long";
		  console.log("TESTCASE3");
        //console.log(test);
		//console.log(temp);
		//console.log(data);
        }
		else if ((/^\d+$/.test(jsonArr[j].lgcy_segment1)) == false) {
			jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be Numeric";
		  //console.log("TESTCASE2");
		}  

        else if (jsonArr[j].start_date_active == undefined || jsonArr[j].start_date_active == null || jsonArr[j].start_date_active == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr[j].start_date_active != undefined) && (jsonArr[j].start_date_active != null) && (jsonArr[j].start_date_active != "") && (jsonArr[j].start_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < jsonArr[j].start_date_active.substring(0, 10))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr[j].interface_type == undefined || jsonArr[j].interface_type == null || jsonArr[j].interface_type == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr[j].interface_type != undefined) && (jsonArr[j].interface_type != null) && (jsonArr[j].interface_type != "I") && (jsonArr[j].interface_type != "O")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }
        else {
          jsonArr[j].flag = "true";
          jsonArr[j].errmsg = "";
        }
      }

      if (mapper == "MCD_TRIRIGA_MAPPER") {
        let lobarr = lineOfBusinessLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment2);
        console.log(lobarr);

        let accountNoarr = accountNoLov.filter(record => record.lookup_code == jsonArr[j].orcl_segment5);
        console.log(accountNoarr);

        let lookupcodearr = lookupcodeLov.filter(record => record.lookup_code == jsonArr[j].lookup_code);
        console.log(lookupcodearr);

        let descriptionarr = descriptionLov.filter(record => record.lookup_code == jsonArr[j].description);
        console.log(descriptionarr);

        if ((jsonArr[j].lookup_code == undefined) || (jsonArr[j].lookup_code == null) || (jsonArr[j].lookup_code == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LOOKUP_CODE (Lookup) is a required field and must be populated";
        }
        else if (lookupcodearr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on LOOKUP_CODE (Lookup)";
        }
        else if (jsonArr[j].description == undefined || jsonArr[j].description == null || jsonArr[j].description == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr[j].description.length > 240) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if (descriptionarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on DESCRIPTION";
        }
        else if ((jsonArr[j].orcl_segment2 == undefined) || (jsonArr[j].orcl_segment2 == null) || (jsonArr[j].orcl_segment2 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT2 (Line of Business) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment2 != undefined) && (jsonArr[j].orcl_segment2 != null) && ((jsonArr[j].orcl_segment2.toString().length != 3) || (/^\d+$/.test(jsonArr[j].orcl_segment2) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT2 (Line of Business) must be 3 positions long and numeric";
        }
        else if (lobarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT2 (Line of Business)";
        }
        else if ((jsonArr[j].orcl_segment5 == undefined) || (jsonArr[j].orcl_segment5 == null) || (jsonArr[j].orcl_segment5 == "")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
        }
        else if ((jsonArr[j].orcl_segment5 != undefined) && (jsonArr[j].orcl_segment5 != null) && ((jsonArr[j].orcl_segment5.toString().length != 9) || (/^\d+$/.test(jsonArr[j].orcl_segment5) == false))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
        }
        else if (accountNoarr <= 0) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid data on ORCL_SEGMENT5 (Account Number)";
        }
        else if (jsonArr[j].start_date_active == undefined || jsonArr[j].start_date_active == null || jsonArr[j].start_date_active == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr[j].start_date_active != undefined) && (jsonArr[j].start_date_active != null) && (jsonArr[j].start_date_active != "") && (jsonArr[j].start_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < today)) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr[j].end_date_active != undefined) && (jsonArr[j].end_date_active != null) && (jsonArr[j].end_date_active != "") && (jsonArr[j].end_date_active.substring(0, 10) < jsonArr[j].start_date_active.substring(0, 10))) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr[j].interface_type == undefined || jsonArr[j].interface_type == null || jsonArr[j].interface_type == "") {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr[j].interface_type != undefined) && (jsonArr[j].interface_type != null) && (jsonArr[j].interface_type != "I") && (jsonArr[j].interface_type != "O")) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }

        else {
          jsonArr[j].flag = "true";
          jsonArr[j].errmsg = "";
        }
      }

    }
    return jsonArr;
  };

  /*import records validations after showing the records in UI for multiple errors in single row */
  PageModule.prototype.validateRecordsEditEndChain = function (jsonArr, ledger, mapper, lineOfBusinessLov, accountNoLov, companyLov, locationLov, hrDepartmentLov, oldDesc, newDesc, newKey, oldKey, oldDate, newDate, lookupLov, descriptionLOV) {

    var flag = "", errmsg = "";
    var i, lineOfBusiness, acctNo, msisAcctNo, val1, val2;

    var now = new Date();
    var day = ("0" + now.getDate()).slice(-2);
    var month = ("0" + (now.getMonth() + 1)).slice(-2);
    var today = now.getFullYear() + "-" + (month) + "-" + (day);

    jsonArr.lookup_type = mapper;
    jsonArr.set_of_books_name = ledger;

    if ((oldDate !== undefined) && (oldDate !== null) && (oldDate !== "")) {
      oldDate = oldDate.substring(0, 10);
    }

    /*Code for updating action flag in on-value change of description and end_date_active*/
    if ((jsonArr.description != undefined) || (jsonArr.description != null) || (jsonArr.description != "") || (jsonArr.end_date_active != undefined) || (jsonArr.end_date_active != null) || (jsonArr.end_date_active != "")) {
      if (jsonArr.enable_flag === undefined) {
        if (jsonArr.action === "F") {
          jsonArr.action = "F";
        }
        else {
          jsonArr.action = "I";
        }
      }
      else {
        if (((oldDesc !== newDesc) && (oldKey == newKey)) || ((oldDate !== newDate) && (oldKey == newKey))) {
          jsonArr.action = "U";
        }
        if ((oldDesc !== newDesc) && (oldKey == newKey)) {
          if (jsonArr.dateFlag == "Y") {
            jsonArr.descFlag = "N";
          } else {
            jsonArr.descFlag = "Y";
          }

        }
        if ((oldDate !== newDate) && (oldKey == newKey)) {
          jsonArr.dateFlag = "Y";
        }
      }
    }
    /* code for updating action flag in on-value change of description and end_date_active end */

    if (jsonArr.action == "F") {
      if (mapper == "ACCOUNT") {
        let lobarr = lineOfBusinessLov.filter(record => record.lookup_code == jsonArr.orcl_segment2);
        console.log(lobarr);

        let accountNoarr = accountNoLov.filter(record => record.lookup_code == jsonArr.orcl_segment5);
        console.log(accountNoarr);
        console.log(/^\d+$/.test(jsonArr.lgcy_segment1));  //testing numeric

        if (jsonArr.description == undefined || jsonArr.description == null || jsonArr.description == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr.description.length > 240) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr.orcl_segment2 == undefined) || (jsonArr.orcl_segment2 == null) || (jsonArr.orcl_segment2 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT2 is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment2 != undefined) && (jsonArr.orcl_segment2 != null) && ((jsonArr.orcl_segment2.toString().length != 3) || (/^\d+$/.test(jsonArr.orcl_segment2) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT2 (Line of Business) must be 3 positions long and numeric";
        }
        else if (lobarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT2 (Line of Business)";
        }
        else if ((jsonArr.orcl_segment5 == undefined) || (jsonArr.orcl_segment5 == null) || (jsonArr.orcl_segment5 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment5 != undefined) && (jsonArr.orcl_segment5 != null) && ((jsonArr.orcl_segment5.toString().length != 9) || (/^\d+$/.test(jsonArr.orcl_segment5) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
        }
        else if (accountNoarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT5 (Account Number)";
        }
        else if ((jsonArr.lgcy_segment1 == undefined) || (jsonArr.lgcy_segment1 == null) || (jsonArr.lgcy_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
        }
		//New changes to modify lgcy_segment1 length to 9 PRB9023639
		// else if ((jsonArr.lgcy_segment1 != undefined) && (jsonArr.lgcy_segment1 != null) && ((jsonArr.lgcy_segment1.toString().length != 7) || (
          else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && (jsonArr[j].lgcy_segment1.toString().length > 9) ) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "TableFieldValidations positions long";
		  console.log("TESTCASE4");
        //console.log(test);
		//console.log(temp);
		//console.log(data);
        }
		else if ((/^\d+$/.test(jsonArr[j].lgcy_segment1)) == false) {
			jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be Numeric";
		  //console.log("TESTCASE2");
		}  
        else if (jsonArr.start_date_active == undefined || jsonArr.start_date_active == null || jsonArr.start_date_active == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr.start_date_active != undefined) && (jsonArr.start_date_active != null) && (jsonArr.start_date_active != "") && (jsonArr.start_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < jsonArr.start_date_active.substring(0, 10))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr.interface_type == undefined || jsonArr.interface_type == null || jsonArr.interface_type == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr.interface_type != undefined) && (jsonArr.interface_type != null) && (jsonArr.interface_type != "I") && (jsonArr.interface_type != "O")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }
        else {
          jsonArr.flag = "true";
          jsonArr.errmsg = "";
        }
      }

      if (mapper == "COMPANY") {
        let companyarr = companyLov.filter(record => record.lookup_code == jsonArr.orcl_segment1);
        console.log(companyLov);

        if (jsonArr.description == undefined || jsonArr.description == null || jsonArr.description == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr.description.length > 240) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr.orcl_segment1 == undefined) || (jsonArr.orcl_segment1 == null) || (jsonArr.orcl_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment1 != undefined) && (jsonArr.orcl_segment1 != null) && (jsonArr.orcl_segment1.toString().length != 5)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT1 (Company) must be 5 positions long and alphanumeric";
        }
        else if ((companyarr <= 0) || (/^[A-Z0-9]*$/.test(jsonArr.orcl_segment1) == false)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT1 (Company)";
        }
        else if ((jsonArr.lgcy_segment1 == undefined) || (jsonArr.lgcy_segment1 == null) || (jsonArr.lgcy_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT2 (Company) is a required field and must be populated";
        }
        else if ((jsonArr.lgcy_segment1 != undefined) && (jsonArr.lgcy_segment1 != null) && ((jsonArr.lgcy_segment1.toString().length != 3) || (/^\d+$/.test(jsonArr.lgcy_segment1) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT2 (Company) must be 3 positions long and numeric";
        }

        else if (jsonArr.start_date_active == undefined || jsonArr.start_date_active == null || jsonArr.start_date_active == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr.start_date_active != undefined) && (jsonArr.start_date_active != null) && (jsonArr.start_date_active != "") && (jsonArr.start_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < jsonArr.start_date_active.substring(0, 10))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr.interface_type == undefined || jsonArr.interface_type == null || jsonArr.interface_type == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr.interface_type != undefined) && (jsonArr.interface_type != null) && (jsonArr.interface_type != "I") && (jsonArr.interface_type != "O")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }

        else {
          jsonArr.flag = "true";
          jsonArr.errmsg = "";
        }
      }

      if (mapper == "DEPARTMENT") {
        let companyarr = companyLov.filter(record => record.lookup_code == jsonArr.orcl_segment1);
        console.log(companyLov);

        let locationarr = locationLov.filter(record => record.lookup_code == jsonArr.orcl_segment3);
        console.log(locationarr);

        let hrDeptCostCentrearr = hrDepartmentLov.filter(record => record.lookup_code == jsonArr.orcl_segment4);
        console.log(hrDeptCostCentrearr);

        if (jsonArr.description == undefined || jsonArr.description == null || jsonArr.description == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr.description.length > 240) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr.orcl_segment1 == undefined) || (jsonArr.orcl_segment1 == null) || (jsonArr.orcl_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT1 (Company) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment1 != undefined) && (jsonArr.orcl_segment1 != null) && (jsonArr.orcl_segment1.toString().length != 5)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT1 (Company) must be 5 positions long and alphanumeric";
        }
        else if ((companyarr <= 0) || (/^[A-Z0-9]*$/.test(jsonArr.orcl_segment1) == false)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT1 (Company)";
        }
        else if ((jsonArr.orcl_segment3 == undefined) || (jsonArr.orcl_segment3 == null) || (jsonArr.orcl_segment3 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT3 (Location) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment3 != undefined) && (jsonArr.orcl_segment3 != null) && ((jsonArr.orcl_segment3.toString().length != 8) || (/^\d+$/.test(jsonArr.orcl_segment3) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT3 (Location) must be 8 positions long and numeric";
        }
        else if (locationarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT3 (Location)";
        }
        else if ((jsonArr.orcl_segment4 == undefined) || (jsonArr.orcl_segment4 == null) || (jsonArr.orcl_segment4 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT4 (HR Dept Cost Center) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment4 != undefined) && (jsonArr.orcl_segment4 != null) && ((jsonArr.orcl_segment4.toString().length != 5) || (/^\d+$/.test(jsonArr.orcl_segment4) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT4 (HR Dept Cost Center) must be 5 positions long and numeric";
        }
        else if (hrDeptCostCentrearr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT4 (HR Dept Cost Center)";
        }
        else if ((jsonArr.lgcy_segment1 == undefined) || (jsonArr.lgcy_segment1 == null) || (jsonArr.lgcy_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT3 (Main (Site/Dept)) is a required field and must be populated";
        }
        else if ((jsonArr.lgcy_segment1 != undefined) && (jsonArr.lgcy_segment1 != null) && ((jsonArr.lgcy_segment1.toString().length > 8) || (/^\d+$/.test(jsonArr.lgcy_segment1) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT3 (Main (Site/Dept)) must be 8 positions long and numeric";
        }
      //  else if ((jsonArr.lgcy_segment2 == undefined) || (jsonArr.lgcy_segment2 == null) || (jsonArr.lgcy_segment2 == "")) {
       //   jsonArr.flag = "false";
        //  jsonArr.errmsg = "LGCY_SEGMENT4 (Sub (Site/Dept)) is a required field and must be populated";
        //}
		//New changes to modify lgcy_segment2 length to 1  PRB9023639
        else if ((jsonArr.lgcy_segment2 != undefined) && (jsonArr.lgcy_segment2 != null) && ((jsonArr.lgcy_segment2.toString().length > 1) || (/^\d+$/.test(jsonArr.lgcy_segment2) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT4 (Sub (Site/Dept)) must be 1 position long and numeric";
        }

        else if (jsonArr.start_date_active == undefined || jsonArr.start_date_active == null || jsonArr.start_date_active == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr.start_date_active != undefined) && (jsonArr.start_date_active != null) && (jsonArr.start_date_active != "") && (jsonArr.start_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < jsonArr.start_date_active.substring(0, 10))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr.interface_type == undefined || jsonArr.interface_type == null || jsonArr.interface_type == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr.interface_type != undefined) && (jsonArr.interface_type != null) && (jsonArr.interface_type != "I") && (jsonArr.interface_type != "O")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }

        else {
          jsonArr.flag = "true";
          jsonArr.errmsg = "";
        }
      }
      if (mapper == "MSIS ACCOUNT NUMBER") {

        if (jsonArr.description == undefined || jsonArr.description == null || jsonArr.description == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr.description.length > 240) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if ((jsonArr.lgcy_segment1 == undefined) || (jsonArr.lgcy_segment1 == null) || (jsonArr.lgcy_segment1 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LGCY_SEGMENT1 (MSIS Account #) is a required field and must be populated";
        }
		// New changes to modify lgcy_segment1 length to 9 PRB9023639
		// else if ((jsonArr.lgcy_segment1 != undefined) && (jsonArr.lgcy_segment1 != null) && ((jsonArr.lgcy_segment1.toString().length != 7) || (
           else if ((jsonArr[j].lgcy_segment1 != undefined) && (jsonArr[j].lgcy_segment1 != null) && (jsonArr[j].lgcy_segment1.toString().length > 9) ) {
          jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be 9 positions long";
		 console.log("TESTCASE5");
        //console.log(test);
		//console.log(temp);
		//console.log(data);
        }
		else if ((/^\d+$/.test(jsonArr[j].lgcy_segment1)) == false) {
			jsonArr[j].flag = "false";
          jsonArr[j].errmsg = "LGCY_SEGMENT1 (MSIS Account #) must be Numeric";
		  //console.log("TESTCASE2");
		}  

        else if (jsonArr.start_date_active == undefined || jsonArr.start_date_active == null || jsonArr.start_date_active == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr.start_date_active != undefined) && (jsonArr.start_date_active != null) && (jsonArr.start_date_active != "") && (jsonArr.start_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < jsonArr.start_date_active.substring(0, 10))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr.interface_type == undefined || jsonArr.interface_type == null || jsonArr.interface_type == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr.interface_type != undefined) && (jsonArr.interface_type != null) && (jsonArr.interface_type != "I") && (jsonArr.interface_type != "O")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }
        else {
          jsonArr.flag = "true";
          jsonArr.errmsg = "";
        }
      }

      if (mapper == "MCD_TRIRIGA_MAPPER") {

        let descriptionarr = descriptionLOV.filter(record => record.lookup_code == jsonArr.description);
        console.log(descriptionarr);

        let lookuparr = lookupLov.filter(record => record.lookup_code == jsonArr.lookup_code);
        console.log(lookuparr);

        let lobarr = lineOfBusinessLov.filter(record => record.lookup_code == jsonArr.orcl_segment2);
        console.log(lobarr);

        let accountNoarr = accountNoLov.filter(record => record.lookup_code == jsonArr.orcl_segment5);
        console.log(accountNoarr);
        console.log(/^\d+$/.test(jsonArr.lgcy_segment1));  //testing numeric 

        if (jsonArr.lookup_code == undefined || jsonArr.lookup_code == null || jsonArr.lookup_code == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "LOOKUP_CODE is a required field and must be populated";
        }
        else if (lookuparr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on LOOKUP_CODE (Lookup)";
        }
        else if (jsonArr.description == undefined || jsonArr.description == null || jsonArr.description == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION is a required field and must be populated";
        }
        else if (jsonArr.description.length > 240) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "DESCRIPTION can only be up to 240 characters";
        }
        else if (descriptionarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on DESCRIPTION";
        }
        else if ((jsonArr.orcl_segment2 == undefined) || (jsonArr.orcl_segment2 == null) || (jsonArr.orcl_segment2 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT2 is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment2 != undefined) && (jsonArr.orcl_segment2 != null) && ((jsonArr.orcl_segment2.toString().length != 3) || (/^\d+$/.test(jsonArr.orcl_segment2) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT2 (Line of Business) must be 3 positions long and numeric";
        }
        else if (lobarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT2 (Line of Business)";
        }
        else if ((jsonArr.orcl_segment5 == undefined) || (jsonArr.orcl_segment5 == null) || (jsonArr.orcl_segment5 == "")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT5 (Account Number) is a required field and must be populated";
        }
        else if ((jsonArr.orcl_segment5 != undefined) && (jsonArr.orcl_segment5 != null) && ((jsonArr.orcl_segment5.toString().length != 9) || (/^\d+$/.test(jsonArr.orcl_segment5) == false))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "ORCL_SEGMENT5 (Account Number) must be 9 positions long and numeric";
        }
        else if (accountNoarr <= 0) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid data on ORCL_SEGMENT5 (Account Number)";
        }

        else if (jsonArr.start_date_active == undefined || jsonArr.start_date_active == null || jsonArr.start_date_active == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE is a required field and must be populated";
        }
        else if ((jsonArr.start_date_active != undefined) && (jsonArr.start_date_active != null) && (jsonArr.start_date_active != "") && (jsonArr.start_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "START DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < today)) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be a date in the past";
        }
        else if ((jsonArr.end_date_active != undefined) && (jsonArr.end_date_active != null) && (jsonArr.end_date_active != "") && (jsonArr.end_date_active.substring(0, 10) < jsonArr.start_date_active.substring(0, 10))) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "END DATE cannot be prior to start date";
        }
        else if (jsonArr.interface_type == undefined || jsonArr.interface_type == null || jsonArr.interface_type == "") {
          jsonArr.flag = "false";
          jsonArr.errmsg = "INTERFACE TYPE is a required field and must be populated";
        }
        else if ((jsonArr.interface_type != undefined) && (jsonArr.interface_type != null) && (jsonArr.interface_type != "I") && (jsonArr.interface_type != "O")) {
          jsonArr.flag = "false";
          jsonArr.errmsg = "Invalid INTERFACE_TYPE. Valid values are 'I' and 'O'";
        }
        else {
          jsonArr.flag = "true";
          jsonArr.errmsg = "";
        }
      }

    }
    return jsonArr;
  };


  PageModule.prototype.validateLedgerAndMapperOnUpload = function (jsonArr, ledger, mapper) {
    var ledgerArr = jsonArr[0][1];
    var mapperArr = jsonArr[1][1];

    if ((ledgerArr != ledger) || (mapperArr != mapper)) {
      return false;
    }
    else return true;
  };


  PageModule.prototype.errorCheckOnUpload = function (jsonArr) {

    for (var j = 0; j < jsonArr.length; j++) {
      if (jsonArr[j].action == 'F') {
        if (jsonArr[j].errmsg != undefined && jsonArr[j].errmsg != "") {
          return false;
        }
      }
    }
    return true;
  };


  PageModule.prototype.importCheck = function (data) {
    for (var i = 0; i < data.length; i++) {
      if (data[i].action != undefined && data[i].action != 'F') {
        return true;
      }
    }
    return false;
  };


  PageModule.prototype.descLengthValidator = function () {
    return [{
      type: 'length',
      options: {
        max: 240,
        messageDetail: {
          tooLong: 'DESCRIPTION can only be 240 positions long'
        }
      }
    }];

  };


  PageModule.prototype.validateDateOnUpload = function (jsonArr) {
    var errordate;

    for (var j = 0; j < jsonArr.length; j++) {

      if (jsonArr[j].start_date_active != undefined) {
        if (isNaN(jsonArr[j].start_date_active)) {
          errordate = "Please define the field in dd-mm-yyyy Format.";
        }
      }

      if (jsonArr[j].end_date_active != undefined) {
        if (isNaN(jsonArr[j].end_date_active)) {
          errordate = "Please define the field in dd-mm-yyyy Format.";
        }
      }
    }
    return errordate;
  };


  PageModule.prototype.validateTemplate = function (jsonArr, mapper) {
    var j, i;

    if (mapper == "ACCOUNT") {
      var xlsHeader = ["Description(alphanumeric maxlength=240)", "Line of Business(3 numeric positions)",
        "Account Number(9 numeric positions)", "MSIS Account Number(7 numeric positions)", "Start Date(MM/DD/YYYY)",
        "End Date(MM/DD/YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      if (xlsHeader.length == jsonArr[2].length) {

        for (i = 0; i < jsonArr[2].length; i++) {
          if (jsonArr[2][i] == undefined) {
            return false;
          }
        }

        if (jsonArr[2][0].indexOf("Description") == -1) {
          return false;
        }
        else if (jsonArr[2][1].indexOf("Line of Business") == -1) {
          return false;
        }
        else if (jsonArr[2][2].indexOf("Account Number") == -1) {
          return false;
        }
        else if (jsonArr[2][3].indexOf("MSIS Account Number") == -1) {
          return false;
        }
        else if (jsonArr[2][4].indexOf("Start Date") == -1) {
          return false;
        }
        else if (jsonArr[2][5].indexOf("End Date") == -1) {
          return false;
        }
        else if (jsonArr[2][6].indexOf("Interface type") == -1) {
          return false;
        }
        return true;
      }
      else return false;
    }

    if (mapper == "COMPANY") {
      var xlsHeaderC = ["Description(alphanumeric maxlength=240)", "Company(5 alphanumeric positions)",
        "Legacy Company(3 numeric positions)", "Start Date(MM/DD/YYYY)", "End Date(MM/DD/YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      if (xlsHeaderC.length == jsonArr[2].length) {

        for (i = 0; i < jsonArr[2].length; i++) {
          if (jsonArr[2][i] == undefined) {
            return false;
          }
        }

        if (jsonArr[2][0].indexOf("Description") == -1) {
          return false;
        }
        else if (jsonArr[2][1].indexOf("Company") == -1) {
          return false;
        }
        else if (jsonArr[2][2].indexOf("Legacy Company") == -1) {
          return false;
        }
        else if (jsonArr[2][3].indexOf("Start Date") == -1) {
          return false;
        }
        else if (jsonArr[2][4].indexOf("End Date") == -1) {
          return false;
        }
        else if (jsonArr[2][5].indexOf("Interface type") == -1) {
          return false;
        }
        /* for( i=0; i<jsonArr[2].length; i++){  
            if(jsonArr[2][i] != xlsHeaderC[i]){
          return false;
         }
       }*/
        return true;
      }
      else return false;
    }

    if (mapper == "DEPARTMENT") {
      var xlsHeaderD = ["Description(alphanumeric maxlength=240)",
        "Company(5 alphanumeric positions)", "Location(8 numeric positions)", "HR Dept Cost Center(5 numeric positions)",
        "Main(Site/Dept)(8 numeric positions)", "Sub(Site/Dept)(2 numeric positions)",
        "Start Date(MM/DD/YYYY)", "End Date(MM/DD/YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      if (xlsHeaderD.length == jsonArr[2].length) {

        for (i = 0; i < jsonArr[2].length; i++) {
          if (jsonArr[2][i] == undefined) {
            return false;
          }
        }

        if (jsonArr[2][0].indexOf("Description") == -1) {
          return false;
        }
        else if (jsonArr[2][1].indexOf("Company") == -1) {
          return false;
        }
        else if (jsonArr[2][2].indexOf("Location") == -1) {
          return false;
        }
        else if (jsonArr[2][3].indexOf("HR Dept Cost Center") == -1) {
          return false;
        }
        else if (jsonArr[2][4].indexOf("Main") == -1) {
          return false;
        }
        else if (jsonArr[2][5].indexOf("Sub") == -1) {
          return false;
        }
        else if (jsonArr[2][6].indexOf("Start Date") == -1) {
          return false;
        }
        else if (jsonArr[2][7].indexOf("End Date") == -1) {
          return false;
        }
        else if (jsonArr[2][8].indexOf("Interface type") == -1) {
          return false;
        }
        return true;
      }
      else return false;
    }

    if (mapper == "MSIS ACCOUNT NUMBER") {
      var xlsHeaderM = ["Description(alphanumeric maxlength=240)", "MSIS Account Number(7 numeric positions)", "Start Date(MM/DD/YYYY)",
        "End Date(MM/DD/YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];
      if (xlsHeaderM.length == jsonArr[2].length) {

        for (i = 0; i < jsonArr[2].length; i++) {
          if (jsonArr[2][i] == undefined) {
            return false;
          }
        }

        if (jsonArr[2][0].indexOf("Description") == -1) {
          return false;
        }
        else if (jsonArr[2][1].indexOf("MSIS Account Number") == -1) {
          return false;
        }
        else if (jsonArr[2][2].indexOf("Start Date") == -1) {
          return false;
        }
        else if (jsonArr[2][3].indexOf("End Date") == -1) {
          return false;
        }
        else if (jsonArr[2][4].indexOf("Interface type") == -1) {
          return false;
        }
        return true;
      }
      else return false;
    }

    if (mapper == "MCD_TRIRIGA_MAPPER") {
      var xlsHeaderT = ["Lookup(Conventional Licensee)", "Description(alphanumeric maxlength=240)", "Line of Business(3 numeric positions)",
        "Account Number(9 numeric positions)", "Start Date(MM/DD/YYYY)",
        "End Date(MM/DD/YYYY)", "Type Interface type('I' for Inbound or 'O' for Outbound)"];

      if (xlsHeaderT.length == jsonArr[2].length) {

        for (i = 0; i < jsonArr[2].length; i++) {
          if (jsonArr[2][i] == undefined) {
            return false;
          }
        }

        if (jsonArr[2][0].indexOf("Lookup") == -1) {
          return false;
        }
        if (jsonArr[2][1].indexOf("Description") == -1) {
          return false;
        }
        else if (jsonArr[2][2].indexOf("Line of Business") == -1) {
          return false;
        }
        else if (jsonArr[2][3].indexOf("Account Number") == -1) {
          return false;
        }
        else if (jsonArr[2][4].indexOf("Start Date") == -1) {
          return false;
        }
        else if (jsonArr[2][5].indexOf("End Date") == -1) {
          return false;
        }
        else if (jsonArr[2][6].indexOf("Interface type") == -1) {
          return false;
        }
        return true;
      }
      else return false;
    }

  };


  /* code for disabling oracle segment fields based on mapper */
  PageModule.prototype.trueADP = function (data1, data2) {

    console.log("data1:" + data1);

    var arr = [false, false, false, false, false, false, false, false];
    for (var i = 0; i < data1.length; i++) {
      if (data1[i].lookup_type == "COMPANY") {
        arr[0] = true;
      }
      else if (data1[i].lookup_type == "LOB") {
        arr[1] = true;
      }
      else if (data1[i].lookup_type == "LOCATION") {
        arr[2] = true;
      }
      else if (data1[i].lookup_type == "HR DEPT COST CENTER") {
        arr[3] = true;
      }
      else if (data1[i].lookup_type == "ACCOUNT_NUMBER") {
        arr[4] = true;
      }
      else if (data1[i].lookup_type == "INTERCOMPANY") {
        arr[5] = true;
      }
      else if (data1[i].lookup_type == "FUTURE1") {
        arr[6] = true;
      }
      else if (data1[i].lookup_type == "FUTURE2") {
        arr[7] = true;
      }
    }
    return arr;
  };


  PageModule.prototype.duplicateRecordsADD = function (data, action, mapperName) {
    var ledger, mapper, company, lineOfBusiness, location, hrDeptCostCenter, accountNumber, legacySegment1, legacySegment2, legacySegment3, legacySegment4, startDate, endDate, interfaceType, lookup, descriptions;

    var picked = "";
    var startDateVal, endDateVal, datearray, date;

    if (typeof data.set_of_books_name === 'undefined') {
      return false;
    }
    else {
      if (data.start_date_active != undefined && data.start_date_active != null && data.start_date_active != "") {
        startDateVal = data.start_date_active.substring(0, 10);
        var dT = startDateVal + "T06:00:00.000Z";
        datearray = new Date(dT);
        date = datearray.getDate() + '-' + (datearray.toLocaleString("en-US", { month: "short" })) + '-' + datearray.getFullYear().toString().substring(2);
        data.start_date_active = date;
        console.log(data);
      }

      if (data.end_date_active != undefined && data.end_date_active != null && data.end_date_active != "") {
        endDateVal = data.end_date_active.substring(0, 10);
        var dT1 = endDateVal + "T06:00:00.000Z";
        datearray = new Date(dT1);
        date = datearray.getDate() + '-' + (datearray.toLocaleString("en-US", { month: "short" })) + '-' + datearray.getFullYear().toString().substring(2);
        data.end_date_active = date;
        console.log(data);
      }

      data.ledger = data.set_of_books_name;
      data.mapper = data.lookup_type;
      data.company = data.orcl_segment1;
      data.lineOfBusiness = data.orcl_segment2;
      data.location = data.orcl_segment3;
      data.hrDeptCostCenter = data.orcl_segment4;
      data.accountNumber = data.orcl_segment5;
      data.legacySegment1 = data.lgcy_segment1;
      data.legacySegment2 = data.lgcy_segment2;
      data.legacySegment3 = data.lgcy_segment3;
      data.legacySegment4 = data.lgcy_segment4;
      data.startDate = data.start_date_active;
      data.endDate = data.end_date_active;
      data.interfaceType = data.interface_type;
      data.lookup = data.lookup_code;
      data.descriptions = data.description;

      delete data.set_of_books_name;
      delete data.lookup_type;
      delete data.orcl_segment1;
      delete data.orcl_segment2;
      delete data.orcl_segment3;
      delete data.orcl_segment4;
      delete data.orcl_segment5;
      delete data.lgcy_segment1;
      delete data.lgcy_segment2;
      delete data.lgcy_segment3;
      delete data.lgcy_segment4;
      delete data.start_date_active;
      delete data.end_date_active;
      delete data.interface_type;
      delete data.lookup_code;
      delete data.description;

      picked = (({ ledger, mapper, company, lineOfBusiness, location, hrDeptCostCenter, accountNumber, legacySegment1, legacySegment2, legacySegment3, legacySegment4, startDate, endDate, interfaceType, lookup, descriptions }) => ({ ledger, mapper, company, lineOfBusiness, location, hrDeptCostCenter, accountNumber, legacySegment1, legacySegment2, legacySegment3, legacySegment4, startDate, endDate, interfaceType, lookup, descriptions }))(data);
      console.log(picked);

    }
    return picked;
  };


  PageModule.prototype.checkDuplicateArrayLength = function (data, jsonArr) {
    console.log(data);
    var errmsg;

    for (var i = 0; i < data.length; i++) {
      var start_date = "", end_date = "";

      if (data[i].start_date_active != undefined && data[i].start_date_active != null && data[i].start_date_active != "") {
        start_date = data[i].start_date_active.substring(0, 10);
      }

      if (data[i].end_date_active != undefined && data[i].end_date_active != null && data[i].end_date_active != "") {
        end_date = data[i].end_date_active.substring(0, 10);
      }

      for (var j = 0; j < jsonArr.length; j++) {
        if ((jsonArr[j].action == "I") || (jsonArr[j].action == "F")) {

          var start_date1 = "", end_date1 = "";

          if (jsonArr[j].start_date_active != undefined && jsonArr[j].start_date_active != null && jsonArr[j].start_date_active != "") {
            start_date1 = jsonArr[j].start_date_active.substring(0, 10);
          }

          if (jsonArr[j].end_date_active != undefined && jsonArr[j].end_date_active != null && jsonArr[j].end_date_active != "") {
            end_date1 = jsonArr[j].end_date_active.substring(0, 10);
          }


          if (data[i].lookup_type == "ACCOUNT") {

            // start date != undefined && End date == undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {                 //duplicate
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 != jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {                 //duplicate for same account number and different msis account number
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 > start_date) {             //UI start date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < start_date) {              //UI start date < DB start date 
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            // start date != undefined && End date != undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate ( (UI start date == db start date) && (UI end date == DB end date) )
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 != jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate for same account number and different msis account number ( (UI start date == db start date) && (UI end date == DB end date))
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date !=undefined && (DB End date != undefined  && UI end date == undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                                        //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date != undefined && (DB end date == undefined && UI end date  != undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && end_date1 > start_date) {                                       //UI start date > DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }
          }

          if (data[i].lookup_type == "COMPANY") {

            // start date != undefined && End date == undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {                 //duplicate
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 > start_date) {             //UI start date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < start_date) {              //UI start date < DB start date 
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            // start date != undefined && End date != undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate ( (UI start date == db start date) && (UI end date == DB end date) )
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date !=undefined && (DB End date != undefined  && UI end date == undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date != undefined && (DB end date == undefined && UI end date  != undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && end_date1 > start_date) {              //UI end date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }
          }

          if (data[i].lookup_type == "DEPARTMENT") {

            // start date != undefined && End date == undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {                 //duplicate
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 > start_date) {             //UI start date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < start_date) {              //UI start date < DB start date 
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            // start date != undefined && End date != undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate ( (UI start date == db start date) && (UI end date == DB end date) )
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date !=undefined && (DB End date != undefined  && UI end date == undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date != undefined && (DB end date == undefined && UI end date  != undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment1 == jsonArr[j].orcl_segment1 && data[i].orcl_segment3 == jsonArr[j].orcl_segment3 && data[i].orcl_segment4 == jsonArr[j].orcl_segment4 && data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].lgcy_segment2 == jsonArr[j].lgcy_segment2 && data[i].interface_type == jsonArr[j].interface_type && end_date1 > start_date) {              //UI start date > DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }
          }

          if (data[i].lookup_type == "MSIS ACCOUNT NUMBER") {

            // start date != undefined && End date == undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {                 //duplicate
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 > start_date) {             //UI start date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
              else if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < start_date) {              //UI start date < DB start date 
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            // start date != undefined && End date != undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate ( (UI start date == db start date) && (UI end date == DB end date) )
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date !=undefined && (DB End date != undefined  && UI end date == undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date != undefined && (DB end date == undefined && UI end date  != undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].lgcy_segment1 == jsonArr[j].lgcy_segment1 && data[i].interface_type == jsonArr[j].interface_type && end_date1 > start_date) {              //UI start date > DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }
          }

          if (data[i].lookup_type == "MCD_TRIRIGA_MAPPER") {
            // start date != undefined && End date == undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date) {
                //duplicate
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 > start_date) {
                //UI start date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 < start_date) {
                //UI start date < DB start date 
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            // start date != undefined && End date != undefined
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 == start_date && end_date1 == end_date) {     // duplicate ( (UI start date == db start date) && (UI end date == DB end date) )
                errmsg = "Duplicate Record - A record already exists with the same information";
              }
              else if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                             //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date !=undefined && (DB End date != undefined  && UI end date == undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active != undefined) && (jsonArr[j].end_date_active == undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && start_date1 < end_date) {                                        //UI start date < DB end date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }

            //start date != undefined && (DB end date == undefined && UI end date  != undefined)
            if ((data[i].start_date_active != undefined) && (jsonArr[j].start_date_active != undefined) && (data[i].end_date_active == undefined) && (jsonArr[j].end_date_active != undefined)) {
              if (data[i].orcl_segment2 == jsonArr[j].orcl_segment2 && data[i].orcl_segment5 == jsonArr[j].orcl_segment5 && data[i].lookup_code == jsonArr[j].lookup_code && data[i].description == jsonArr[j].description && data[i].interface_type == jsonArr[j].interface_type && end_date1 > start_date) {                                       //UI end date > DB start date
                errmsg = "Record cannot be added because there's an existing record with an overlapping date";
              }
            }
          }


        }
      }
    }
    /* if(data.length >0){
       return false;
      }
      else return true; */
    return errmsg;
  };


  PageModule.prototype.startDateCheckOnLoad = function (recArr) {

    for (var j = 0; j < recArr.length; j++) {

      if (recArr[j].start_date_active != undefined && recArr[j].start_date_active != null && recArr[j].start_date_active != "") {

        var offset = new Date().getTimezoneOffset();// getting offset to make time in gmt+0 zone (UTC) (for gmt+5 offset comes as -300 minutes)
        var date1 = recArr[j].start_date_active.substring(0, 10);
        var date = new Date(date1);
        date.setMinutes(date.getMinutes() + offset);// date now in UTC time

        var utc = date.toUTCString();
        var utcDate = new Date(date);
        var isoDate = utcDate.toISOString();
        recArr[j].start_date_active = isoDate.substring(0, 10) + "T00:00:00Z";
      }
    }
    return recArr;
  };

  PageModule.prototype.setValueForAttribute1 = function (data) {

    var attri1;

    if (data.indexOf("AU") > -1) {
      attri1 = "AU";
    }
    else if (data.indexOf("NZ") > -1) {
      attri1 = "NZ";
    }

    return attri1;

  };

  PageModule.prototype.pickStartDate = function (data) {
    console.log("picked start date : " + data);

    if (typeof data === "string") {
      data = data.substring(0, 10);
    }
    return data;
  };

  PageModule.prototype.pickendDate = function (data) {
    console.log("picked start date : " + data);

    if (typeof data === "string") {
      data = data.substring(0, 10);
    }
    return data;
  };


  PageModule.prototype.falseADP = function (data) {
    console.log(data);

  };

  PageModule.prototype.removeDuplicatesMapperADP = function (data) {
    return [...new Map(data.map(item => [item["lookup_code"], item])).values()];
  };

  PageModule.prototype.removeDuplicatesledgerADP = function (data) {
    
    return [...new Map(data.map(item => [item["set_of_boks_name"], item])).values()];

  };
  

  PageModule.prototype.roleflag = function (data, ledger, mapper, roles) {
    var ledgerLC, mapperLC, role_flag,i;

    // ledgerLC = ledger.toLowerCase();
    mapperLC = mapper.toLowerCase();
    if (ledger == "MCD AU Primary Ledger" && mapper == "ACCOUNT") {
      for (i = 0; i < roles.length; i++) {
        if ((roles[i] == "paasmapper_mcdpaas_au_account_readwrite")){
          role_flag = "true";
        }
      }
    }
    else if (ledger == "MCD AU Primary Ledger" && mapper == "COMPANY") {
      for (i = 0; i < roles.length; i++) {
        if (roles[i] == "paasmapper_mcdpaas_au_company_readwrite") {
          role_flag = "true";
        }        
      }
    }
    else if (ledger == "MCD AU Primary Ledger" && mapper == "DEPARTMENT") {
       for (i = 0; i < roles.length; i++) {
        if (roles[i] == "paasmapper_mcdpaas_au_department_readwrite") {
          role_flag = "true";         
        }
      }
    }
    else if (ledger == "MCD AU Primary Ledger" && mapper == "MSIS ACCOUNT NUMBER") {
      for (i = 0; i < roles.length; i++) {
        if (roles[i] =="paasmapper_mcdpaas_au_msisaccountnumber_readwrite") {
          role_flag = "true";         
        }
      }
    }
    else if (ledger == "MCD AU Primary Ledger" && mapper == "MCD_TRIRIGA_MAPPER") {
      for (i = 0; i < roles.length; i++) {
        if (roles[i] == "paasmapper_mcdpaas_au_tririga_readwrite") {
          role_flag = "True";         
        }
      }
    }
    else if (ledger == "MCD NZ Primary Ledger" && mapper == "ACCOUNT") {
      for (i = 0; i < roles.length; i++) {
        if ((roles[i] =="paasmapper_mcdpaas_nz_account_readwrite")) {
          role_flag = "true";
        }
      }
    }
    else if (ledger == "MCD NZ Primary Ledger" && mapper == "COMPANY") {
      for (i = 0; i < roles.length; i++) {
        if ((roles[i] =="paasmapper_mcdpaas_nz_company_readwrite")) {
          role_flag = "true";
        }
      }
    }
    else if (ledger == "MCD NZ Primary Ledger" && mapper == "DEPARTMENT") {
      for (i = 0; i < roles.length; i++) {
        if ((roles[i]=="paasmapper_mcdpaas_nz_department_readwrite")) {
          role_flag = "true";         
        }
      }
    }
    else if (ledger == "MCD NZ Primary Ledger" && mapper == "MSIS ACCOUNT NUMBER") {
      for (i = 0; i < roles.length; i++) {
        if ((roles[i] =="paasmapper_mcdpaas_nz_msisaccountnumber_readwrite")) {
          role_flag = "true";         
        }
      }
    }
    else if (ledger == "MCD NZ Primary Ledger" && mapper == "MCD_TRIRIGA_MAPPER") {
       for (i = 0; i < roles.length; i++) {
        if (roles[i]== "paasmapper_mcdpaas_nz_tririga_readwrite") {
          role_flag = "true";         
        }
      }
    }
  return role_flag;
  };


  return PageModule;
});

